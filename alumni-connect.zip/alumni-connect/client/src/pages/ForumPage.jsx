import { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import api from '../utils/api';
import { formatDistanceToNow } from 'date-fns';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';

const CATEGORIES = [
  { value: '', label: 'All', emoji: '🌐' },
  { value: 'general', label: 'General', emoji: '💬' },
  { value: 'career', label: 'Career', emoji: '💼' },
  { value: 'technical', label: 'Technical', emoji: '⚙️' },
  { value: 'events', label: 'Events', emoji: '📅' },
  { value: 'opportunities', label: 'Opportunities', emoji: '🚀' },
  { value: 'alumni-advice', label: 'Alumni Advice', emoji: '🎓' },
];

export default function ForumPage() {
  const { user } = useAuth();
  const [posts, setPosts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [category, setCategory] = useState('');
  const [search, setSearch] = useState('');
  const [sortBy, setSortBy] = useState('recent');
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [total, setTotal] = useState(0);

  const fetchPosts = useCallback(async (p = 1) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ category, search, sortBy, page: p, limit: 10 });
      const { data } = await api.get(`/forum?${params}`);
      setPosts(data.posts);
      setPages(data.pages);
      setTotal(data.total);
      setPage(p);
    } catch { toast.error('Failed to load posts'); }
    finally { setLoading(false); }
  }, [category, search, sortBy]);

  useEffect(() => { fetchPosts(1); }, [fetchPosts]);

  const handleLike = async (e, postId) => {
    e.preventDefault();
    try {
      const { data } = await api.post(`/forum/${postId}/like`);
      setPosts(ps => ps.map(p => p._id === postId ? { ...p, likes: Array(data.likes).fill('') } : p));
    } catch { toast.error('Failed to like'); }
  };

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">Discussion Forum</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">{total} discussions</p>
        </div>
        <Link to="/forum/create" className="btn-primary">+ New Post</Link>
      </div>

      {/* Categories */}
      <div className="flex gap-2 overflow-x-auto pb-1 -mx-1 px-1">
        {CATEGORIES.map(c => (
          <button key={c.value} onClick={() => setCategory(c.value)}
            className={`flex-shrink-0 flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-medium transition-all ${
              category === c.value
                ? 'bg-brand-600 text-white shadow-sm'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-slate-700 hover:border-brand-300'
            }`}>
            {c.emoji} {c.label}
          </button>
        ))}
      </div>

      {/* Search & sort */}
      <div className="flex gap-3">
        <input className="input-field flex-1" placeholder="🔍 Search discussions..." value={search}
          onChange={e => setSearch(e.target.value)} />
        <select className="input-field w-40 flex-shrink-0 text-sm" value={sortBy} onChange={e => setSortBy(e.target.value)}>
          <option value="recent">Most Recent</option>
          <option value="popular">Most Liked</option>
          <option value="views">Most Viewed</option>
        </select>
      </div>

      {/* Posts */}
      {loading ? (
        <div className="space-y-4">
          {[...Array(5)].map((_, i) => <div key={i} className="animate-pulse h-32 bg-slate-100 dark:bg-slate-800 rounded-2xl" />)}
        </div>
      ) : posts.length === 0 ? (
        <div className="card p-12 text-center">
          <div className="text-5xl mb-3">💬</div>
          <h3 className="font-semibold text-slate-700 dark:text-slate-300">No discussions yet</h3>
          <Link to="/forum/create" className="btn-primary mt-4 inline-flex">Start the conversation</Link>
        </div>
      ) : (
        <div className="space-y-3 animate-stagger">
          {posts.map(post => (
            <Link key={post._id} to={`/forum/post/${post._id}`}
              className="card-hover p-5 block group">
              <div className="flex items-start gap-4">
                {post.isPinned && <span className="text-amber-500 text-sm flex-shrink-0 mt-0.5">📌</span>}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start gap-3">
                    {post.author?.avatar
                      ? <img src={post.author.avatar} className="w-8 h-8 rounded-full object-cover flex-shrink-0" />
                      : <div className="w-8 h-8 rounded-full bg-brand-100 dark:bg-brand-900 flex items-center justify-center text-brand-700 text-xs font-bold flex-shrink-0">
                          {post.author?.name?.[0]}
                        </div>
                    }
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-slate-900 dark:text-slate-100 group-hover:text-brand-700 dark:group-hover:text-brand-400 transition-colors line-clamp-1">
                        {post.title}
                      </h3>
                      <p className="text-sm text-slate-500 dark:text-slate-400 line-clamp-2 mt-0.5">{post.content}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 mt-3 flex-wrap">
                    <span className="text-xs text-slate-400">
                      {post.author?.name} · {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
                    </span>
                    {post.category && (
                      <span className="badge-primary text-xs">
                        {CATEGORIES.find(c => c.value === post.category)?.emoji} {post.category}
                      </span>
                    )}
                    {post.tags?.slice(0, 2).map(tag => (
                      <span key={tag} className="text-xs text-slate-400"># {tag}</span>
                    ))}
                  </div>
                </div>
                <div className="flex items-center gap-4 text-sm text-slate-400 flex-shrink-0">
                  <button onClick={(e) => handleLike(e, post._id)} className="flex items-center gap-1 hover:text-rose-500 transition-colors">
                    ❤ {post.likes?.length || 0}
                  </button>
                  <span className="flex items-center gap-1">💬 {post.comments?.length || 0}</span>
                  <span className="flex items-center gap-1 hidden sm:flex">👁 {post.views || 0}</span>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}

      {pages > 1 && (
        <div className="flex justify-center gap-2">
          <button disabled={page <= 1} onClick={() => fetchPosts(page - 1)} className="btn-secondary text-sm disabled:opacity-40">← Prev</button>
          <span className="flex items-center px-4 text-sm text-slate-500">Page {page} of {pages}</span>
          <button disabled={page >= pages} onClick={() => fetchPosts(page + 1)} className="btn-secondary text-sm disabled:opacity-40">Next →</button>
        </div>
      )}
    </div>
  );
}
