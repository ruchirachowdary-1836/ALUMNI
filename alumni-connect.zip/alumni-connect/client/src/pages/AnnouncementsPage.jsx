import { useState, useEffect } from 'react';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { format, formatDistanceToNow } from 'date-fns';

const TYPE_CONFIG = {
  announcement: { emoji: '📢', label: 'Announcement', color: 'bg-brand-50 dark:bg-brand-950 border-brand-100 dark:border-brand-900' },
  event: { emoji: '📅', label: 'Event', color: 'bg-emerald-50 dark:bg-emerald-950 border-emerald-100 dark:border-emerald-900' },
  opportunity: { emoji: '💼', label: 'Opportunity', color: 'bg-amber-50 dark:bg-amber-950 border-amber-100 dark:border-amber-900' },
  news: { emoji: '📰', label: 'News', color: 'bg-violet-50 dark:bg-violet-950 border-violet-100 dark:border-violet-900' },
};

export default function AnnouncementsPage() {
  const { user } = useAuth();
  const [announcements, setAnnouncements] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [form, setForm] = useState({ title: '', content: '', type: 'announcement', eventDate: '', location: '', registrationLink: '', tags: '' });
  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }));

  const canPost = ['alumni', 'admin'].includes(user?.role);

  const fetchAnnouncements = async () => {
    try {
      const params = filter ? `?type=${filter}` : '';
      const { data } = await api.get(`/announcements${params}`);
      setAnnouncements(data.announcements);
    } catch { toast.error('Failed to load announcements'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchAnnouncements(); }, [filter]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title || !form.content) return toast.error('Title and content required');
    setSubmitting(true);
    try {
      const payload = { ...form, tags: form.tags.split(',').map(t => t.trim()).filter(Boolean) };
      const { data } = await api.post('/announcements', payload);
      setAnnouncements(prev => [data, ...prev]);
      setForm({ title: '', content: '', type: 'announcement', eventDate: '', location: '', registrationLink: '', tags: '' });
      setShowForm(false);
      toast.success('Posted successfully!');
    } catch (err) { toast.error(err.response?.data?.message || 'Failed to post'); }
    finally { setSubmitting(false); }
  };

  const handleDelete = async (id) => {
    if (!confirm('Delete this announcement?')) return;
    try {
      await api.delete(`/announcements/${id}`);
      setAnnouncements(prev => prev.filter(a => a._id !== id));
      toast.success('Deleted');
    } catch { toast.error('Failed to delete'); }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">Announcements & Events</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Stay updated with the latest from your community</p>
        </div>
        {canPost && (
          <button onClick={() => setShowForm(s => !s)} className="btn-primary">
            {showForm ? '✕ Cancel' : '+ Post'}
          </button>
        )}
      </div>

      {/* Type filters */}
      <div className="flex gap-2 flex-wrap">
        {[{ value: '', label: 'All', emoji: '🌐' }, ...Object.entries(TYPE_CONFIG).map(([k, v]) => ({ value: k, label: v.label, emoji: v.emoji }))].map(t => (
          <button key={t.value} onClick={() => setFilter(t.value)}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-medium transition-all border ${
              filter === t.value
                ? 'bg-brand-600 text-white border-brand-600 shadow-sm'
                : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-brand-300'
            }`}>
            {t.emoji} {t.label}
          </button>
        ))}
      </div>

      {/* Post form */}
      {showForm && (
        <div className="card p-6 animate-slide-up">
          <h2 className="section-title mb-4">New Post</h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2">
                <input className="input-field" placeholder="Title *" value={form.title} onChange={set('title')} />
              </div>
              <select className="input-field text-sm" value={form.type} onChange={set('type')}>
                {Object.entries(TYPE_CONFIG).map(([k, v]) => <option key={k} value={k}>{v.emoji} {v.label}</option>)}
              </select>
              {['event', 'opportunity'].includes(form.type) && (
                <input className="input-field text-sm" type="date" value={form.eventDate} onChange={set('eventDate')} />
              )}
            </div>
            <textarea className="input-field resize-none" rows={4} placeholder="Content *" value={form.content} onChange={set('content')} />
            {form.type === 'event' && (
              <div className="grid grid-cols-2 gap-3">
                <input className="input-field text-sm" placeholder="Location" value={form.location} onChange={set('location')} />
                <input className="input-field text-sm" placeholder="Registration link (optional)" value={form.registrationLink} onChange={set('registrationLink')} />
              </div>
            )}
            <input className="input-field text-sm" placeholder="Tags (comma-separated)" value={form.tags} onChange={set('tags')} />
            <div className="flex gap-3">
              <button type="submit" disabled={submitting} className="btn-primary">
                {submitting ? <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" /> : '✦ Post'}
              </button>
              <button type="button" onClick={() => setShowForm(false)} className="btn-secondary">Cancel</button>
            </div>
          </form>
        </div>
      )}

      {/* List */}
      {loading ? (
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => <div key={i} className="animate-pulse h-40 bg-slate-100 dark:bg-slate-800 rounded-2xl" />)}
        </div>
      ) : announcements.length === 0 ? (
        <div className="card p-12 text-center">
          <div className="text-5xl mb-3">📢</div>
          <h3 className="font-semibold text-slate-700 dark:text-slate-300">No announcements</h3>
          {canPost && <button onClick={() => setShowForm(true)} className="btn-primary mt-4 inline-flex">Post First Announcement</button>}
        </div>
      ) : (
        <div className="space-y-4 animate-stagger">
          {announcements.map(a => {
            const config = TYPE_CONFIG[a.type] || TYPE_CONFIG.announcement;
            return (
              <div key={a._id} className={`card p-5 border ${config.color}`}>
                {a.isPinned && <div className="text-amber-500 text-xs font-medium mb-2">📌 Pinned</div>}
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3 flex-1">
                    <span className="text-2xl flex-shrink-0 mt-0.5">{config.emoji}</span>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-semibold text-slate-900 dark:text-slate-100">{a.title}</h3>
                        <span className={`badge text-xs ${
                          a.type === 'event' ? 'bg-emerald-100 text-emerald-700' :
                          a.type === 'opportunity' ? 'bg-amber-100 text-amber-700' :
                          'badge-primary'
                        }`}>{config.label}</span>
                      </div>
                      <p className="text-sm text-slate-600 dark:text-slate-400 mt-1.5 leading-relaxed whitespace-pre-line">
                        {a.content.length > 300 ? `${a.content.slice(0, 300)}...` : a.content}
                      </p>

                      {/* Event details */}
                      <div className="flex flex-wrap gap-4 mt-3 text-sm text-slate-500 dark:text-slate-400">
                        {a.eventDate && (
                          <span className="flex items-center gap-1.5">
                            📅 {format(new Date(a.eventDate), 'PPP')}
                          </span>
                        )}
                        {a.location && <span className="flex items-center gap-1.5">📍 {a.location}</span>}
                      </div>

                      {a.registrationLink && (
                        <a href={a.registrationLink} target="_blank" rel="noreferrer"
                          className="inline-flex items-center gap-1.5 mt-3 btn-primary text-xs py-1.5 px-4">
                          🔗 Register Now
                        </a>
                      )}

                      {a.tags?.length > 0 && (
                        <div className="flex flex-wrap gap-1.5 mt-3">
                          {a.tags.map(tag => (
                            <span key={tag} className="text-xs px-2 py-0.5 bg-white/60 dark:bg-slate-800/60 text-slate-500 rounded-lg"># {tag}</span>
                          ))}
                        </div>
                      )}

                      <div className="flex items-center gap-3 mt-3 pt-3 border-t border-black/5 dark:border-white/5 text-xs text-slate-400">
                        <div className="flex items-center gap-1.5">
                          {a.author?.avatar
                            ? <img src={a.author.avatar} className="w-4 h-4 rounded-full object-cover" alt="" />
                            : <div className="w-4 h-4 rounded-full bg-brand-100 flex items-center justify-center text-brand-700 text-xs">{a.author?.name?.[0]}</div>
                          }
                          <span>{a.author?.name}</span>
                        </div>
                        <span>·</span>
                        <span>{formatDistanceToNow(new Date(a.createdAt), { addSuffix: true })}</span>
                      </div>
                    </div>
                  </div>
                  {(user?._id === a.author?._id || user?.role === 'admin') && (
                    <button onClick={() => handleDelete(a._id)} className="btn-ghost text-rose-400 hover:bg-rose-50 text-sm p-2 flex-shrink-0">🗑</button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
