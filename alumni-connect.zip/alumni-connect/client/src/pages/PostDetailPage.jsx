import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { formatDistanceToNow } from 'date-fns';

const Avatar = ({ user, size = 8 }) => {
  const s = `w-${size} h-${size}`;
  return user?.avatar
    ? <img src={user.avatar} alt={user.name} className={`${s} rounded-full object-cover flex-shrink-0`} />
    : <div className={`${s} rounded-full bg-brand-100 dark:bg-brand-900 flex items-center justify-center text-brand-700 dark:text-brand-300 text-xs font-bold flex-shrink-0`}>
        {user?.name?.[0]}
      </div>;
};

export default function PostDetailPage() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [post, setPost] = useState(null);
  const [loading, setLoading] = useState(true);
  const [comment, setComment] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [replyTo, setReplyTo] = useState(null);
  const [replyText, setReplyText] = useState('');
  const [liked, setLiked] = useState(false);

  useEffect(() => {
    api.get(`/forum/${id}`)
      .then(r => {
        setPost(r.data);
        setLiked(r.data.likes?.includes(user?._id));
      })
      .catch(() => toast.error('Failed to load post'))
      .finally(() => setLoading(false));
  }, [id, user]);

  const handleLike = async () => {
    try {
      const { data } = await api.post(`/forum/${id}/like`);
      setLiked(data.liked);
      setPost(p => ({ ...p, likes: Array(data.likes).fill('') }));
    } catch { toast.error('Failed'); }
  };

  const handleComment = async (e) => {
    e.preventDefault();
    if (!comment.trim()) return;
    setSubmitting(true);
    try {
      const { data } = await api.post(`/forum/${id}/comments`, { content: comment });
      setPost(p => ({ ...p, comments: [...(p.comments || []), data] }));
      setComment('');
      toast.success('Comment added!');
    } catch { toast.error('Failed to add comment'); }
    finally { setSubmitting(false); }
  };

  const handleReply = async (commentId) => {
    if (!replyText.trim()) return;
    setSubmitting(true);
    try {
      const { data } = await api.post(`/forum/${id}/comments/${commentId}/reply`, { content: replyText });
      setPost(p => ({
        ...p,
        comments: p.comments.map(c =>
          c._id === commentId ? { ...c, replies: [...(c.replies || []), data] } : c
        ),
      }));
      setReplyTo(null);
      setReplyText('');
    } catch { toast.error('Failed to reply'); }
    finally { setSubmitting(false); }
  };

  const handleDelete = async () => {
    if (!confirm('Delete this post?')) return;
    try {
      await api.delete(`/forum/${id}`);
      toast.success('Post deleted');
      navigate('/forum');
    } catch { toast.error('Failed to delete'); }
  };

  if (loading) return (
    <div className="flex justify-center py-20">
      <div className="w-8 h-8 border-4 border-brand-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );
  if (!post) return <div className="card p-12 text-center">Post not found</div>;

  const CATEGORY_LABELS = {
    general: '💬 General', career: '💼 Career', technical: '⚙️ Technical',
    events: '📅 Events', opportunities: '🚀 Opportunities', 'alumni-advice': '🎓 Alumni Advice',
  };

  return (
    <div className="max-w-2xl mx-auto space-y-5 animate-fade-in">
      {/* Back */}
      <button onClick={() => navigate('/forum')} className="btn-ghost text-sm">← Back to Forum</button>

      {/* Post */}
      <div className="card p-6">
        {post.isPinned && <div className="text-amber-500 text-sm mb-3">📌 Pinned Post</div>}
        <div className="flex items-start gap-4 mb-4">
          <Avatar user={post.author} size={10} />
          <div className="flex-1">
            <div className="flex items-center gap-2 flex-wrap">
              <Link to={`/profile/${post.author?._id}`} className="font-semibold text-slate-900 dark:text-slate-100 hover:text-brand-700 transition-colors">
                {post.author?.name}
              </Link>
              <span className={`badge text-xs ${post.author?.role === 'alumni' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                {post.author?.role}
              </span>
              {post.author?.company && <span className="text-xs text-slate-400">@ {post.author.company}</span>}
            </div>
            <div className="flex items-center gap-3 mt-0.5 text-xs text-slate-400">
              <span>{formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}</span>
              {post.category && <span className="badge-primary">{CATEGORY_LABELS[post.category]}</span>}
            </div>
          </div>
          {(user?._id === post.author?._id || user?.role === 'admin') && (
            <button onClick={handleDelete} className="btn-ghost text-rose-500 hover:bg-rose-50 text-sm p-2">🗑</button>
          )}
        </div>

        <h1 className="text-xl font-bold text-slate-900 dark:text-slate-100 mb-3">{post.title}</h1>
        <div className="prose prose-sm max-w-none text-slate-700 dark:text-slate-300 whitespace-pre-wrap leading-relaxed">
          {post.content}
        </div>

        {post.tags?.length > 0 && (
          <div className="flex flex-wrap gap-2 mt-4">
            {post.tags.map(tag => (
              <span key={tag} className="text-xs px-2.5 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-500 dark:text-slate-400 rounded-lg"># {tag}</span>
            ))}
          </div>
        )}

        <div className="flex items-center gap-4 mt-5 pt-4 border-t border-slate-100 dark:border-slate-800">
          <button onClick={handleLike}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-medium transition-all ${
              liked ? 'bg-rose-50 dark:bg-rose-900/20 text-rose-600 dark:text-rose-400' : 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-500'
            }`}>
            {liked ? '❤️' : '🤍'} {post.likes?.length || 0} Likes
          </button>
          <span className="flex items-center gap-1.5 text-sm text-slate-400">
            💬 {post.comments?.length || 0} Comments
          </span>
          <span className="flex items-center gap-1.5 text-sm text-slate-400">
            👁 {post.views || 0} Views
          </span>
        </div>
      </div>

      {/* Comment form */}
      <div className="card p-5">
        <h3 className="section-title mb-4">Leave a Comment</h3>
        <form onSubmit={handleComment} className="flex gap-3">
          <Avatar user={user} size={9} />
          <div className="flex-1">
            <textarea
              className="input-field resize-none"
              rows={3}
              placeholder="Share your thoughts..."
              value={comment}
              onChange={e => setComment(e.target.value)}
            />
            <div className="flex justify-end mt-2">
              <button type="submit" disabled={submitting || !comment.trim()} className="btn-primary text-sm">
                {submitting ? <span className="w-3 h-3 border-2 border-white/40 border-t-white rounded-full animate-spin" /> : 'Post Comment'}
              </button>
            </div>
          </div>
        </form>
      </div>

      {/* Comments */}
      {post.comments?.length > 0 && (
        <div className="card p-5 space-y-5">
          <h3 className="section-title">{post.comments.length} Comments</h3>
          {post.comments.map(c => (
            <div key={c._id} className="flex gap-3">
              <Avatar user={c.author} size={8} />
              <div className="flex-1">
                <div className="bg-slate-50 dark:bg-slate-800 rounded-xl p-3">
                  <div className="flex items-center gap-2 mb-1">
                    <Link to={`/profile/${c.author?._id}`} className="text-sm font-semibold text-slate-800 dark:text-slate-200 hover:text-brand-700 transition-colors">
                      {c.author?.name}
                    </Link>
                    <span className="text-xs text-slate-400">{formatDistanceToNow(new Date(c.createdAt), { addSuffix: true })}</span>
                  </div>
                  <p className="text-sm text-slate-700 dark:text-slate-300">{c.content}</p>
                </div>
                <button onClick={() => setReplyTo(replyTo === c._id ? null : c._id)}
                  className="text-xs text-slate-400 hover:text-brand-600 mt-1.5 ml-3 transition-colors">
                  ↩ Reply
                </button>

                {/* Replies */}
                {c.replies?.length > 0 && (
                  <div className="mt-3 space-y-3 ml-4 pl-4 border-l-2 border-slate-100 dark:border-slate-700">
                    {c.replies.map((r, i) => (
                      <div key={i} className="flex gap-2">
                        <Avatar user={r.author} size={7} />
                        <div className="flex-1 bg-slate-50 dark:bg-slate-800 rounded-xl p-2.5">
                          <div className="flex items-center gap-2 mb-0.5">
                            <span className="text-xs font-semibold text-slate-700 dark:text-slate-300">{r.author?.name}</span>
                            <span className="text-xs text-slate-400">{formatDistanceToNow(new Date(r.createdAt), { addSuffix: true })}</span>
                          </div>
                          <p className="text-xs text-slate-600 dark:text-slate-400">{r.content}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Reply form */}
                {replyTo === c._id && (
                  <div className="mt-3 ml-4 flex gap-2">
                    <Avatar user={user} size={7} />
                    <div className="flex-1 flex gap-2">
                      <input
                        className="input-field text-sm flex-1"
                        placeholder="Write a reply..."
                        value={replyText}
                        onChange={e => setReplyText(e.target.value)}
                        autoFocus
                      />
                      <button onClick={() => handleReply(c._id)} disabled={submitting || !replyText.trim()} className="btn-primary text-xs px-3">
                        Send
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
