import { useState, useEffect } from 'react';
import api from '../utils/api';
import toast from 'react-hot-toast';
import { Link } from 'react-router-dom';
import { formatDistanceToNow } from 'date-fns';

const StatCard = ({ label, value, icon, color }) => (
  <div className="card p-5 flex items-center gap-4">
    <div className={`w-12 h-12 rounded-xl ${color} flex items-center justify-center text-xl flex-shrink-0`}>{icon}</div>
    <div>
      <div className="text-2xl font-bold text-slate-900 dark:text-slate-100">{value ?? '—'}</div>
      <div className="text-sm text-slate-500 dark:text-slate-400">{label}</div>
    </div>
  </div>
);

export default function AdminPage() {
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('overview');
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('');
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalUsers, setTotalUsers] = useState(0);

  useEffect(() => {
    api.get('/admin/stats')
      .then(r => setStats(r.data))
      .catch(() => toast.error('Failed to load stats'));
  }, []);

  const fetchUsers = async (p = 1) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ search, role: roleFilter, page: p, limit: 15 });
      const { data } = await api.get(`/admin/users?${params}`);
      setUsers(data.users);
      setTotalPages(data.pages);
      setTotalUsers(data.total);
      setPage(p);
    } catch { toast.error('Failed to load users'); }
    finally { setLoading(false); }
  };

  useEffect(() => {
    if (tab === 'users') fetchUsers(1);
    else setLoading(false);
  }, [tab, search, roleFilter]);

  const handleBan = async (userId, isBanned) => {
    try {
      await api.patch(`/admin/users/${userId}/ban`);
      setUsers(prev => prev.map(u => u._id === userId ? { ...u, isBanned: !u.isBanned } : u));
      toast.success(isBanned ? 'User unbanned' : 'User banned');
    } catch { toast.error('Action failed'); }
  };

  const handleRoleChange = async (userId, newRole) => {
    try {
      const { data } = await api.patch(`/admin/users/${userId}/role`, { role: newRole });
      setUsers(prev => prev.map(u => u._id === userId ? { ...u, role: data.role } : u));
      toast.success('Role updated');
    } catch { toast.error('Failed to update role'); }
  };

  const handleApprove = async (userId) => {
    try {
      const { data } = await api.patch(`/admin/users/${userId}/approve`);
      setUsers(prev => prev.map(u => u._id === userId ? { ...u, isApproved: true, isVerified: true } : u));
      toast.success('User approved and verified');
    } catch { toast.error('Failed to approve'); }
  };

  const TABS = [
    { key: 'overview', label: '📊 Overview' },
    { key: 'users', label: '👥 Users' },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="page-title">Admin Panel</h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">Manage users, content, and platform settings</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800 w-fit">
        {TABS.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={`px-5 py-2 rounded-lg text-sm font-medium transition-all ${
              tab === t.key ? 'bg-brand-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}>
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'overview' && (
        <div className="space-y-6 animate-stagger">
          <div className="grid grid-cols-2 lg:grid-cols-3 gap-4">
            <StatCard label="Total Users" value={stats?.totalUsers} icon="👥" color="bg-brand-50 dark:bg-brand-950 text-brand-600" />
            <StatCard label="Alumni" value={stats?.alumni} icon="🎓" color="bg-emerald-50 dark:bg-emerald-950 text-emerald-600" />
            <StatCard label="Students" value={stats?.students} icon="📚" color="bg-amber-50 dark:bg-amber-950 text-amber-600" />
            <StatCard label="Forum Posts" value={stats?.totalPosts} icon="💬" color="bg-violet-50 dark:bg-violet-950 text-violet-600" />
            <StatCard label="Announcements" value={stats?.totalAnnouncements} icon="📢" color="bg-teal-50 dark:bg-teal-950 text-teal-600" />
            <StatCard label="Banned Users" value={stats?.bannedUsers} icon="🚫" color="bg-rose-50 dark:bg-rose-950 text-rose-600" />
          </div>
          <div className="card p-6">
            <h2 className="section-title mb-3">Quick Actions</h2>
            <div className="flex flex-wrap gap-3">
              <button onClick={() => setTab('users')} className="btn-secondary">👥 Manage Users</button>
              <Link to="/announcements" className="btn-secondary">📢 View Announcements</Link>
              <Link to="/forum" className="btn-secondary">💬 Moderate Forum</Link>
            </div>
          </div>
        </div>
      )}

      {tab === 'users' && (
        <div className="space-y-4">
          <div className="flex flex-wrap gap-3">
            <input className="input-field flex-1 min-w-48" placeholder="🔍 Search by name or email..." value={search}
              onChange={e => setSearch(e.target.value)} />
            <select className="input-field w-40 text-sm" value={roleFilter} onChange={e => setRoleFilter(e.target.value)}>
              <option value="">All roles</option>
              <option value="student">Students</option>
              <option value="alumni">Alumni</option>
              <option value="admin">Admins</option>
            </select>
          </div>
          <div className="text-sm text-slate-500 dark:text-slate-400">{totalUsers} users found</div>

          {loading ? (
            <div className="space-y-2">
              {[...Array(5)].map((_, i) => <div key={i} className="animate-pulse h-16 bg-slate-100 dark:bg-slate-800 rounded-xl" />)}
            </div>
          ) : (
            <div className="card overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-slate-100 dark:border-slate-800">
                      <th className="text-left text-xs font-semibold text-slate-500 dark:text-slate-400 px-4 py-3">User</th>
                      <th className="text-left text-xs font-semibold text-slate-500 dark:text-slate-400 px-4 py-3 hidden sm:table-cell">Contact</th>
                      <th className="text-left text-xs font-semibold text-slate-500 dark:text-slate-400 px-4 py-3">Role</th>
                      <th className="text-left text-xs font-semibold text-slate-500 dark:text-slate-400 px-4 py-3 hidden md:table-cell">Status</th>
                      <th className="text-left text-xs font-semibold text-slate-500 dark:text-slate-400 px-4 py-3 hidden lg:table-cell">Joined</th>
                      <th className="text-left text-xs font-semibold text-slate-500 dark:text-slate-400 px-4 py-3">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {users.map(u => (
                      <tr key={u._id} className={`border-b border-slate-50 dark:border-slate-800/50 hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors ${u.isBanned ? 'opacity-60' : ''}`}>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-2.5">
                            {u.avatar
                              ? <img src={u.avatar} className="w-8 h-8 rounded-full object-cover" alt="" />
                              : <div className="w-8 h-8 rounded-full bg-brand-100 dark:bg-brand-900 flex items-center justify-center text-brand-700 text-xs font-bold">{u.name?.[0]}</div>
                            }
                            <div>
                              <Link to={`/profile/${u._id}`} className="text-sm font-medium text-slate-800 dark:text-slate-200 hover:text-brand-700 block truncate max-w-32">
                                {u.name}
                              </Link>
                              {u.company && <p className="text-xs text-slate-400 truncate max-w-32">{u.company}</p>}
                            </div>
                          </div>
                        </td>
                        <td className="px-4 py-3 hidden sm:table-cell">
                          <div className="text-xs text-slate-500 dark:text-slate-400">
                            <div className="truncate max-w-40">{u.email || '—'}</div>
                            {u.phone && <div>{u.phone}</div>}
                          </div>
                        </td>
                        <td className="px-4 py-3">
                          <select
                            value={u.role}
                            onChange={e => handleRoleChange(u._id, e.target.value)}
                            className="text-xs px-2 py-1 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 cursor-pointer"
                          >
                            <option value="student">Student</option>
                            <option value="alumni">Alumni</option>
                            <option value="admin">Admin</option>
                          </select>
                        </td>
                        <td className="px-4 py-3 hidden md:table-cell">
                          <div className="flex flex-col gap-1">
                            {u.isBanned
                              ? <span className="badge-danger">Banned</span>
                              : u.isVerified
                              ? <span className="badge-success">Verified</span>
                              : <span className="badge-warning">Unverified</span>
                            }
                            {!u.isApproved && <span className="badge-warning">Pending</span>}
                          </div>
                        </td>
                        <td className="px-4 py-3 hidden lg:table-cell text-xs text-slate-400">
                          {u.createdAt ? formatDistanceToNow(new Date(u.createdAt), { addSuffix: true }) : '—'}
                        </td>
                        <td className="px-4 py-3">
                          <div className="flex items-center gap-1.5">
                            {!u.isApproved && (
                              <button onClick={() => handleApprove(u._id)}
                                className="text-xs px-2 py-1 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20 rounded-lg transition-colors">
                                ✓ Approve
                              </button>
                            )}
                            <button onClick={() => handleBan(u._id, u.isBanned)}
                              className={`text-xs px-2 py-1 rounded-lg transition-colors ${
                                u.isBanned
                                  ? 'text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-900/20'
                                  : 'text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/20'
                              }`}>
                              {u.isBanned ? '↩ Unban' : '🚫 Ban'}
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {totalPages > 1 && (
            <div className="flex justify-center gap-2">
              <button disabled={page <= 1} onClick={() => fetchUsers(page - 1)} className="btn-secondary text-sm disabled:opacity-40">← Prev</button>
              <span className="flex items-center px-4 text-sm text-slate-500">Page {page} of {totalPages}</span>
              <button disabled={page >= totalPages} onClick={() => fetchUsers(page + 1)} className="btn-secondary text-sm disabled:opacity-40">Next →</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
