import { useState, useEffect, useCallback } from 'react';
import { Link } from 'react-router-dom';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';

const UserCard = ({ user, onConnect, connectionStatus }) => (
  <div className="card-hover p-5 group animate-fade-in">
    <div className="flex items-start gap-4">
      <Link to={`/profile/${user._id}`}>
        {user.avatar
          ? <img src={user.avatar} alt={user.name} className="w-14 h-14 rounded-2xl object-cover" />
          : <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-brand-400 to-brand-600 flex items-center justify-center text-white text-lg font-bold">
              {user.name?.[0]}
            </div>
        }
      </Link>
      <div className="flex-1 min-w-0">
        <Link to={`/profile/${user._id}`}>
          <h3 className="font-semibold text-slate-900 dark:text-slate-100 hover:text-brand-700 dark:hover:text-brand-400 transition-colors truncate">
            {user.name}
            {user.isVerified && <span className="ml-1 text-brand-500 text-xs">✓</span>}
          </h3>
        </Link>
        <p className="text-sm text-slate-500 dark:text-slate-400 truncate">
          {user.jobTitle ? `${user.jobTitle} at ${user.company}` : user.company || user.branch}
        </p>
        <div className="flex flex-wrap gap-1.5 mt-2">
          {user.batch && <span className="badge-primary text-xs">Batch '{user.batch}</span>}
          <span className={`badge text-xs ${user.role === 'alumni' ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/50 dark:text-emerald-400' : 'bg-amber-100 text-amber-700 dark:bg-amber-900/50 dark:text-amber-400'}`}>
            {user.role}
          </span>
        </div>
      </div>
    </div>
    {user.skills?.length > 0 && (
      <div className="flex flex-wrap gap-1.5 mt-3">
        {user.skills.slice(0, 3).map(s => (
          <span key={s} className="text-xs px-2 py-0.5 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-lg">{s}</span>
        ))}
        {user.skills.length > 3 && <span className="text-xs text-slate-400">+{user.skills.length - 3}</span>}
      </div>
    )}
    <div className="flex items-center gap-2 mt-4 pt-3 border-t border-slate-100 dark:border-slate-800">
      {connectionStatus === 'connected' ? (
        <span className="text-xs text-emerald-600 dark:text-emerald-400 font-medium flex-1">✓ Connected</span>
      ) : connectionStatus === 'pending' ? (
        <span className="text-xs text-amber-600 dark:text-amber-400 font-medium flex-1">⏳ Request Sent</span>
      ) : connectionStatus === 'received' ? (
        <Link to="/connections" className="text-xs text-brand-600 font-medium flex-1 hover:underline">Respond to Request →</Link>
      ) : (
        <button onClick={() => onConnect(user._id)} className="btn-secondary text-xs py-1.5 px-3">
          + Connect
        </button>
      )}
      {user.linkedin && (
        <a href={user.linkedin} target="_blank" rel="noreferrer"
          className="text-xs px-3 py-1.5 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors">
          LinkedIn
        </a>
      )}
      {user.github && (
        <a href={user.github} target="_blank" rel="noreferrer"
          className="text-xs px-3 py-1.5 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors">
          GitHub
        </a>
      )}
    </div>
  </div>
);

export default function DirectoryPage() {
  const { user: currentUser } = useAuth();
  const [users, setUsers] = useState([]);
  const [filters, setFilters] = useState({ batches: [], companies: [], domains: [] });
  const [query, setQuery] = useState({ search: '', batch: '', company: '', domain: '', role: '', sortBy: 'name' });
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [pages, setPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [myConnections, setMyConnections] = useState({ connections: [], sentRequests: [], pendingRequests: [] });

  useEffect(() => {
    api.get('/directory/filters').then(r => setFilters(r.data)).catch(() => {});
    api.get('/connections/my').then(r => setMyConnections(r.data)).catch(() => {});
  }, []);

  const fetchUsers = useCallback(async (p = 1) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ ...query, page: p, limit: 12 });
      const { data } = await api.get(`/directory?${params}`);
      setUsers(data.users);
      setTotal(data.total);
      setPages(data.pages);
      setPage(p);
    } catch { toast.error('Failed to load directory'); }
    finally { setLoading(false); }
  }, [query]);

  useEffect(() => { fetchUsers(1); }, [fetchUsers]);

  const handleConnect = async (targetId) => {
    try {
      await api.post(`/connections/request/${targetId}`);
      setMyConnections(prev => ({ ...prev, sentRequests: [...prev.sentRequests, { _id: targetId }] }));
      toast.success('Connection request sent!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to send request');
    }
  };

  const getStatus = (userId) => {
    if (userId === currentUser?._id) return 'self';
    if (myConnections.connections?.some(c => c._id === userId || c === userId)) return 'connected';
    if (myConnections.sentRequests?.some(c => c._id === userId || c === userId)) return 'pending';
    if (myConnections.pendingRequests?.some(c => c._id === userId || c === userId)) return 'received';
    return 'none';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="page-title">Alumni Directory</h1>
          <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">{total} members found</p>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="card p-4 space-y-3">
        <input
          className="input-field text-base"
          placeholder="🔍 Search by name, company, or role..."
          value={query.search}
          onChange={e => setQuery(q => ({ ...q, search: e.target.value }))}
        />
        <div className="flex flex-wrap gap-3">
          <select className="input-field flex-1 min-w-32 text-sm" value={query.role} onChange={e => setQuery(q => ({ ...q, role: e.target.value }))}>
            <option value="">All roles</option>
            <option value="alumni">Alumni</option>
            <option value="student">Students</option>
          </select>
          <select className="input-field flex-1 min-w-32 text-sm" value={query.batch} onChange={e => setQuery(q => ({ ...q, batch: e.target.value }))}>
            <option value="">All batches</option>
            {filters.batches.map(b => <option key={b} value={b}>{b}</option>)}
          </select>
          <select className="input-field flex-1 min-w-32 text-sm" value={query.domain} onChange={e => setQuery(q => ({ ...q, domain: e.target.value }))}>
            <option value="">All domains</option>
            {filters.domains.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
          <select className="input-field flex-1 min-w-32 text-sm" value={query.sortBy} onChange={e => setQuery(q => ({ ...q, sortBy: e.target.value }))}>
            <option value="name">Sort: Name</option>
            <option value="batch">Sort: Batch</option>
            <option value="company">Sort: Company</option>
            <option value="recent">Sort: Recent</option>
          </select>
          {(query.search || query.batch || query.domain || query.role) && (
            <button onClick={() => setQuery({ search: '', batch: '', company: '', domain: '', role: '', sortBy: 'name' })}
              className="btn-ghost text-sm text-rose-500">✕ Clear</button>
          )}
        </div>
      </div>

      {/* Grid */}
      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => <div key={i} className="animate-pulse h-52 bg-slate-100 dark:bg-slate-800 rounded-2xl" />)}
        </div>
      ) : users.length === 0 ? (
        <div className="card p-12 text-center">
          <div className="text-5xl mb-3">🔍</div>
          <h3 className="font-semibold text-slate-700 dark:text-slate-300">No results found</h3>
          <p className="text-slate-400 text-sm mt-1">Try adjusting your search filters</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 animate-stagger">
          {users.filter(u => u._id !== currentUser?._id).map(u => (
            <UserCard key={u._id} user={u} onConnect={handleConnect} connectionStatus={getStatus(u._id)} />
          ))}
        </div>
      )}

      {/* Pagination */}
      {pages > 1 && (
        <div className="flex justify-center gap-2">
          <button disabled={page <= 1} onClick={() => fetchUsers(page - 1)} className="btn-secondary text-sm disabled:opacity-40">← Prev</button>
          <span className="flex items-center px-4 text-sm text-slate-500">Page {page} of {pages}</span>
          <button disabled={page >= pages} onClick={() => fetchUsers(page + 1)} className="btn-secondary text-sm disabled:opacity-40">Next →</button>
        </div>
      )}
    </div>
  );
}
