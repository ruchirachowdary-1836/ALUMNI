import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';
import { formatDistanceToNow } from 'date-fns';

const StatCard = ({ label, value, icon, color }) => (
  <div className="card p-5 flex items-center gap-4">
    <div className={`w-12 h-12 rounded-xl ${color} flex items-center justify-center text-xl flex-shrink-0`}>{icon}</div>
    <div>
      <div className="text-2xl font-bold text-slate-900 dark:text-slate-100">{value}</div>
      <div className="text-sm text-slate-500 dark:text-slate-400">{label}</div>
    </div>
  </div>
);

export default function DashboardPage() {
  const { user } = useAuth();
  const [recentPosts, setRecentPosts] = useState([]);
  const [announcements, setAnnouncements] = useState([]);
  const [connections, setConnections] = useState({ connections: [], pendingRequests: [] });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      try {
        const [postsRes, annRes, connRes] = await Promise.all([
          api.get('/forum?limit=4'),
          api.get('/announcements?limit=3'),
          api.get('/connections/my'),
        ]);
        setRecentPosts(postsRes.data.posts);
        setAnnouncements(annRes.data.announcements);
        setConnections(connRes.data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const profileComplete = [
    user?.bio, user?.branch, user?.batch, user?.company || user?.role === 'student',
    user?.skills?.length,
  ].filter(Boolean).length;
  const profilePct = Math.round((profileComplete / 5) * 100);

  return (
    <div className="space-y-6 animate-stagger">
      {/* Welcome */}
      <div className="card p-6 bg-gradient-to-r from-brand-600 to-brand-700 text-white border-0">
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold">Welcome back, {user?.name?.split(' ')[0]}! 👋</h1>
            <p className="text-brand-100 mt-1">
              {user?.role === 'student' ? 'Explore alumni connections and opportunities.' : 'Help students with your experience and insights.'}
            </p>
          </div>
          <Link to={`/profile/${user?._id}`} className="flex-shrink-0">
            {user?.avatar
              ? <img src={user.avatar} alt="" className="w-14 h-14 rounded-2xl object-cover border-2 border-white/30" />
              : <div className="w-14 h-14 rounded-2xl bg-white/20 flex items-center justify-center text-2xl font-bold">
                  {user?.name?.[0]}
                </div>
            }
          </Link>
        </div>
        {profilePct < 100 && (
          <div className="mt-4">
            <div className="flex justify-between text-xs text-brand-200 mb-1.5">
              <span>Profile completion</span>
              <span>{profilePct}%</span>
            </div>
            <div className="h-1.5 bg-white/20 rounded-full">
              <div className="h-1.5 bg-white rounded-full transition-all" style={{ width: `${profilePct}%` }} />
            </div>
            <Link to="/profile/edit" className="mt-2 inline-block text-xs text-brand-100 hover:text-white underline">
              Complete your profile →
            </Link>
          </div>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Connections" value={connections.connections.length} icon="🤝" color="bg-brand-50 dark:bg-brand-950 text-brand-600" />
        <StatCard label="Pending Requests" value={connections.pendingRequests.length} icon="⏳" color="bg-amber-50 dark:bg-amber-950 text-amber-600" />
        <StatCard label="Recent Posts" value={recentPosts.length} icon="💬" color="bg-emerald-50 dark:bg-emerald-950 text-emerald-600" />
        <StatCard label="Events" value={announcements.length} icon="📅" color="bg-violet-50 dark:bg-violet-950 text-violet-600" />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Recent Forum Posts */}
        <div className="lg:col-span-2 card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="section-title">Recent Discussions</h2>
            <Link to="/forum" className="text-sm text-brand-600 dark:text-brand-400 hover:underline font-medium">View all →</Link>
          </div>
          {loading ? (
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => (
                <div key={i} className="animate-pulse h-16 bg-slate-100 dark:bg-slate-800 rounded-xl" />
              ))}
            </div>
          ) : recentPosts.length === 0 ? (
            <div className="text-center py-8 text-slate-400">
              <div className="text-4xl mb-2">💬</div>
              <p>No posts yet</p>
              <Link to="/forum/create" className="text-brand-600 text-sm hover:underline">Start a discussion</Link>
            </div>
          ) : (
            <div className="space-y-3">
              {recentPosts.map(post => (
                <Link key={post._id} to={`/forum/post/${post._id}`}
                  className="flex items-start gap-3 p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors group">
                  {post.author?.avatar
                    ? <img src={post.author.avatar} className="w-8 h-8 rounded-full object-cover flex-shrink-0 mt-0.5" />
                    : <div className="w-8 h-8 rounded-full bg-brand-100 dark:bg-brand-900 flex items-center justify-center text-brand-700 text-xs font-bold flex-shrink-0 mt-0.5">
                        {post.author?.name?.[0]}
                      </div>
                  }
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-slate-800 dark:text-slate-200 line-clamp-1 group-hover:text-brand-700 dark:group-hover:text-brand-400 transition-colors">
                      {post.title}
                    </p>
                    <p className="text-xs text-slate-400 mt-0.5">
                      {post.author?.name} · {formatDistanceToNow(new Date(post.createdAt), { addSuffix: true })}
                    </p>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-slate-400 flex-shrink-0">
                    <span>❤ {post.likes?.length}</span>
                    <span>💬 {post.comments?.length}</span>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </div>

        {/* Announcements */}
        <div className="card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="section-title">Announcements</h2>
            <Link to="/announcements" className="text-sm text-brand-600 dark:text-brand-400 hover:underline font-medium">All →</Link>
          </div>
          {loading ? (
            <div className="space-y-3">
              {[...Array(3)].map((_, i) => <div key={i} className="animate-pulse h-20 bg-slate-100 dark:bg-slate-800 rounded-xl" />)}
            </div>
          ) : announcements.length === 0 ? (
            <div className="text-center py-6 text-slate-400 text-sm">No announcements</div>
          ) : (
            <div className="space-y-3">
              {announcements.map(a => (
                <div key={a._id} className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700">
                  <div className="flex items-start gap-2">
                    <span className="text-lg flex-shrink-0">
                      {a.type === 'event' ? '📅' : a.type === 'opportunity' ? '💼' : '📢'}
                    </span>
                    <div>
                      <p className="text-sm font-medium text-slate-800 dark:text-slate-200 line-clamp-2">{a.title}</p>
                      <p className="text-xs text-slate-400 mt-0.5">
                        {formatDistanceToNow(new Date(a.createdAt), { addSuffix: true })}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Pending connection requests */}
      {connections.pendingRequests.length > 0 && (
        <div className="card p-5">
          <h2 className="section-title mb-4">Connection Requests ({connections.pendingRequests.length})</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {connections.pendingRequests.slice(0, 3).map(req => (
              <div key={req._id} className="flex items-center gap-3 p-3 bg-slate-50 dark:bg-slate-800 rounded-xl">
                {req.avatar
                  ? <img src={req.avatar} className="w-10 h-10 rounded-full object-cover" />
                  : <div className="w-10 h-10 rounded-full bg-brand-100 dark:bg-brand-900 flex items-center justify-center text-brand-700 font-semibold">
                      {req.name?.[0]}
                    </div>
                }
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-800 dark:text-slate-200 truncate">{req.name}</p>
                  <p className="text-xs text-slate-400 truncate">{req.company || req.batch || req.role}</p>
                </div>
                <Link to="/connections" className="text-xs text-brand-600 hover:underline font-medium">View</Link>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
