import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import api from '../utils/api';
import toast from 'react-hot-toast';

const UserChip = ({ user, actions }) => (
  <div className="card p-4 flex items-center gap-3">
    <Link to={`/profile/${user._id}`}>
      {user.avatar
        ? <img src={user.avatar} className="w-12 h-12 rounded-full object-cover" alt={user.name} />
        : <div className="w-12 h-12 rounded-full bg-gradient-to-br from-brand-400 to-brand-600 flex items-center justify-center text-white font-bold">
            {user.name?.[0]}
          </div>
      }
    </Link>
    <div className="flex-1 min-w-0">
      <Link to={`/profile/${user._id}`} className="font-semibold text-sm text-slate-900 dark:text-slate-100 hover:text-brand-700 truncate block">
        {user.name}
      </Link>
      <p className="text-xs text-slate-400 truncate">
        {user.jobTitle ? `${user.jobTitle}${user.company ? ` @ ${user.company}` : ''}` : user.batch || user.role}
      </p>
      <span className={`badge text-xs mt-1 ${user.role === 'alumni' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
        {user.role}
      </span>
    </div>
    <div className="flex flex-col gap-1.5 flex-shrink-0">{actions}</div>
  </div>
);

export default function ConnectionsPage() {
  const [data, setData] = useState({ connections: [], pendingRequests: [], sentRequests: [] });
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('connections');

  const fetchConnections = async () => {
    try {
      const { data: d } = await api.get('/connections/my');
      setData(d);
    } catch { toast.error('Failed to load connections'); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchConnections(); }, []);

  const handleRespond = async (senderId, action) => {
    try {
      await api.post(`/connections/respond/${senderId}`, { action });
      toast.success(action === 'accept' ? 'Connection accepted!' : 'Request rejected');
      fetchConnections();
    } catch { toast.error('Failed'); }
  };

  const handleRemove = async (targetId) => {
    if (!confirm('Remove this connection?')) return;
    try {
      await api.delete(`/connections/${targetId}`);
      toast.success('Connection removed');
      fetchConnections();
    } catch { toast.error('Failed'); }
  };

  const TABS = [
    { key: 'connections', label: 'My Connections', count: data.connections.length },
    { key: 'pending', label: 'Requests', count: data.pendingRequests.length },
    { key: 'sent', label: 'Sent', count: data.sentRequests.length },
  ];

  if (loading) return (
    <div className="flex justify-center py-20">
      <div className="w-8 h-8 border-4 border-brand-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  return (
    <div className="space-y-5">
      <h1 className="page-title">Connections</h1>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-white dark:bg-slate-900 rounded-xl border border-slate-100 dark:border-slate-800 w-fit">
        {TABS.map(t => (
          <button key={t.key} onClick={() => setTab(t.key)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              tab === t.key ? 'bg-brand-600 text-white shadow-sm' : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}>
            {t.label}
            {t.count > 0 && (
              <span className={`text-xs rounded-full w-5 h-5 flex items-center justify-center ${
                tab === t.key ? 'bg-white/20 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400'
              }`}>{t.count}</span>
            )}
          </button>
        ))}
      </div>

      {/* Content */}
      {tab === 'connections' && (
        <div>
          {data.connections.length === 0 ? (
            <div className="card p-12 text-center">
              <div className="text-5xl mb-3">🤝</div>
              <h3 className="font-semibold text-slate-700 dark:text-slate-300">No connections yet</h3>
              <p className="text-slate-400 text-sm mt-1">Explore the directory to connect with alumni</p>
              <Link to="/directory" className="btn-primary mt-4 inline-flex">Browse Directory</Link>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 animate-stagger">
              {data.connections.map(u => (
                <UserChip key={u._id} user={u} actions={
                  <>
                    <Link to={`/messages/${u._id}`} className="btn-primary text-xs py-1.5 px-3">💬 Message</Link>
                    <button onClick={() => handleRemove(u._id)} className="text-xs text-slate-400 hover:text-rose-500 transition-colors text-center">Remove</button>
                  </>
                } />
              ))}
            </div>
          )}
        </div>
      )}

      {tab === 'pending' && (
        <div>
          {data.pendingRequests.length === 0 ? (
            <div className="card p-12 text-center">
              <div className="text-4xl mb-3">✉️</div>
              <h3 className="font-semibold text-slate-700 dark:text-slate-300">No pending requests</h3>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 gap-4 animate-stagger">
              {data.pendingRequests.map(u => (
                <UserChip key={u._id} user={u} actions={
                  <>
                    <button onClick={() => handleRespond(u._id, 'accept')} className="btn-primary text-xs py-1.5 px-3">✓ Accept</button>
                    <button onClick={() => handleRespond(u._id, 'reject')} className="btn-secondary text-xs py-1.5 px-3 text-rose-500">✕ Decline</button>
                  </>
                } />
              ))}
            </div>
          )}
        </div>
      )}

      {tab === 'sent' && (
        <div>
          {data.sentRequests.length === 0 ? (
            <div className="card p-12 text-center">
              <div className="text-4xl mb-3">📤</div>
              <h3 className="font-semibold text-slate-700 dark:text-slate-300">No sent requests</h3>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 animate-stagger">
              {data.sentRequests.map(u => (
                <UserChip key={u._id} user={u} actions={
                  <span className="text-xs text-amber-600 dark:text-amber-400 font-medium px-3 py-1 bg-amber-50 dark:bg-amber-900/20 rounded-lg">⏳ Pending</span>
                } />
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
