import { Link } from 'react-router-dom';

export default function NotFoundPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-50 dark:bg-slate-950">
      <div className="text-center px-4">
        <div className="text-8xl mb-6">🎓</div>
        <h1 className="text-6xl font-bold text-brand-600 mb-2">404</h1>
        <h2 className="text-2xl font-semibold text-slate-800 dark:text-slate-200 mb-3">Page Not Found</h2>
        <p className="text-slate-500 dark:text-slate-400 mb-8 max-w-sm mx-auto">
          Looks like this page took a different career path. Let's get you back on track.
        </p>
        <Link to="/dashboard" className="btn-primary inline-flex">← Back to Dashboard</Link>
      </div>
    </div>
  );
}
