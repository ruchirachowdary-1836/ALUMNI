import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import toast from 'react-hot-toast';
import { formatDistanceToNow } from 'date-fns';

export default function ProfilePage() {
  const { id } = useParams();
  const { user: currentUser } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [connectionStatus, setConnectionStatus] = useState('none');
  const [myConn, setMyConn] = useState(null);

  const isOwn = id === currentUser?._id || id === 'me';

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const userId = isOwn ? currentUser._id : id;
        const [profileRes, connRes] = await Promise.all([
          api.get(`/users/${userId}`),
          api.get('/connections/my'),
        ]);
        setProfile(profileRes.data);
        setMyConn(connRes.data);
        const conn = connRes.data;
        if (conn.connections?.some(c => (c._id || c) === userId)) setConnectionStatus('connected');
        else if (conn.sentRequests?.some(c => (c._id || c) === userId)) setConnectionStatus('pending');
        else if (conn.pendingRequests?.some(c => (c._id || c) === userId)) setConnectionStatus('received');
      } catch {
        toast.error('Failed to load profile');
      } finally {
        setLoading(false);
      }
    };
    fetchProfile();
  }, [id, isOwn, currentUser]);

  const handleConnect = async () => {
    try {
      await api.post(`/connections/request/${profile._id}`);
      setConnectionStatus('pending');
      toast.success('Connection request sent!');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed');
    }
  };

  if (loading) return (
    <div className="flex justify-center py-20">
      <div className="w-8 h-8 border-4 border-brand-500 border-t-transparent rounded-full animate-spin" />
    </div>
  );

  if (!profile) return <div className="card p-12 text-center"><p>Profile not found</p></div>;

  const avatarColors = ['from-brand-400 to-brand-600', 'from-teal-400 to-teal-600', 'from-violet-400 to-violet-600', 'from-rose-400 to-rose-600'];
  const colorIdx = profile.name?.charCodeAt(0) % avatarColors.length || 0;

  return (
    <div className="max-w-3xl mx-auto space-y-5 animate-fade-in">
      {/* Header card */}
      <div className="card overflow-hidden">
        <div className="h-32 bg-gradient-to-r from-brand-600 via-brand-500 to-accent-violet relative">
          <div className="absolute inset-0 opacity-20"
            style={{ backgroundImage: 'radial-gradient(circle at 20% 50%, white 1px, transparent 1px), radial-gradient(circle at 80% 20%, white 1px, transparent 1px)', backgroundSize: '30px 30px' }} />
        </div>
        <div className="px-6 pb-6">
          <div className="flex items-end justify-between -mt-12 mb-4">
            {profile.avatar
              ? <img src={profile.avatar} alt={profile.name} className="w-24 h-24 rounded-2xl object-cover border-4 border-white dark:border-slate-900 shadow-lg" />
              : <div className={`w-24 h-24 rounded-2xl bg-gradient-to-br ${avatarColors[colorIdx]} flex items-center justify-center text-white text-3xl font-bold border-4 border-white dark:border-slate-900 shadow-lg`}>
                  {profile.name?.[0]}
                </div>
            }
            <div className="flex items-center gap-2 mb-2">
              {isOwn ? (
                <Link to="/profile/edit" className="btn-secondary text-sm">✏️ Edit Profile</Link>
              ) : (
                <>
                  {connectionStatus === 'connected' && (
                    <Link to={`/messages/${profile._id}`} className="btn-primary text-sm">💬 Message</Link>
                  )}
                  {connectionStatus === 'none' && (
                    <button onClick={handleConnect} className="btn-primary text-sm">+ Connect</button>
                  )}
                  {connectionStatus === 'pending' && (
                    <span className="badge-warning text-sm px-4 py-2">⏳ Pending</span>
                  )}
                  {connectionStatus === 'received' && (
                    <Link to="/connections" className="btn-primary text-sm">Respond →</Link>
                  )}
                  {connectionStatus === 'connected' && (
                    <span className="badge-success">✓ Connected</span>
                  )}
                </>
              )}
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-2xl font-bold text-slate-900 dark:text-slate-100">{profile.name}</h1>
              {profile.isVerified && <span className="badge-primary text-xs">✓ Verified</span>}
              <span className={`badge text-xs ${profile.role === 'alumni' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                {profile.role}
              </span>
            </div>
            {(profile.jobTitle || profile.company) && (
              <p className="text-slate-600 dark:text-slate-400 mt-1">
                {profile.jobTitle}{profile.jobTitle && profile.company ? ' at ' : ''}<strong>{profile.company}</strong>
              </p>
            )}
            {profile.location && <p className="text-sm text-slate-400 mt-0.5">📍 {profile.location}</p>}
            {profile.bio && <p className="text-sm text-slate-600 dark:text-slate-400 mt-3 leading-relaxed">{profile.bio}</p>}
          </div>
        </div>
      </div>

      {/* Details */}
      <div className="grid md:grid-cols-2 gap-5">
        <div className="card p-5 space-y-4">
          <h2 className="section-title">Education & Career</h2>
          {[
            { label: 'Branch', value: profile.branch, icon: '🎓' },
            { label: 'Batch', value: profile.batch, icon: '📅' },
            { label: 'Domain', value: profile.domain, icon: '🏷️' },
            { label: 'Company', value: profile.company, icon: '🏢' },
            { label: 'Role', value: profile.jobTitle, icon: '💼' },
          ].filter(f => f.value).map(f => (
            <div key={f.label} className="flex items-center gap-3">
              <span className="text-lg">{f.icon}</span>
              <div>
                <div className="text-xs text-slate-400">{f.label}</div>
                <div className="text-sm font-medium text-slate-700 dark:text-slate-300">{f.value}</div>
              </div>
            </div>
          ))}
        </div>

        <div className="card p-5 space-y-4">
          <h2 className="section-title">Skills & Links</h2>
          {profile.skills?.length > 0 && (
            <div>
              <div className="text-xs text-slate-400 mb-2">Skills</div>
              <div className="flex flex-wrap gap-2">
                {profile.skills.map(s => (
                  <span key={s} className="text-xs px-2.5 py-1 bg-brand-50 dark:bg-brand-950 text-brand-700 dark:text-brand-300 rounded-lg font-medium">{s}</span>
                ))}
              </div>
            </div>
          )}
          <div className="space-y-2">
            {profile.linkedin && (
              <a href={profile.linkedin} target="_blank" rel="noreferrer"
                className="flex items-center gap-2 text-sm text-blue-600 hover:underline">
                🔗 LinkedIn Profile
              </a>
            )}
            {profile.github && (
              <a href={profile.github} target="_blank" rel="noreferrer"
                className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-400 hover:underline">
                🐙 GitHub Profile
              </a>
            )}
            {profile.website && (
              <a href={profile.website} target="_blank" rel="noreferrer"
                className="flex items-center gap-2 text-sm text-brand-600 hover:underline">
                🌐 Website
              </a>
            )}
          </div>
          <div className="text-xs text-slate-400 pt-2 border-t border-slate-100 dark:border-slate-800">
            Member since {profile.createdAt ? new Date(profile.createdAt).toLocaleDateString('en-US', { month: 'long', year: 'numeric' }) : 'N/A'}
          </div>
        </div>
      </div>

      {/* Connections preview */}
      {profile.connections?.length > 0 && (
        <div className="card p-5">
          <h2 className="section-title mb-4">{profile.connections.length} Connections</h2>
          <div className="flex flex-wrap gap-3">
            {profile.connections.slice(0, 8).map(conn => (
              <Link key={conn._id} to={`/profile/${conn._id}`} className="flex items-center gap-2 hover:opacity-80 transition-opacity">
                {conn.avatar
                  ? <img src={conn.avatar} className="w-10 h-10 rounded-full object-cover" />
                  : <div className="w-10 h-10 rounded-full bg-brand-100 dark:bg-brand-900 flex items-center justify-center text-brand-700 text-sm font-bold">{conn.name?.[0]}</div>
                }
                <div>
                  <div className="text-xs font-medium text-slate-700 dark:text-slate-300 truncate max-w-24">{conn.name}</div>
                  <div className="text-xs text-slate-400 truncate max-w-24">{conn.company || conn.batch}</div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
