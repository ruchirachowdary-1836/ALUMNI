import { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';
import { getSocket } from '../utils/socket';
import toast from 'react-hot-toast';
import { formatDistanceToNow, format, isToday } from 'date-fns';

const formatTime = (date) => {
  const d = new Date(date);
  return isToday(d) ? format(d, 'HH:mm') : format(d, 'MMM d, HH:mm');
};

export default function MessagesPage() {
  const { userId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [conversations, setConversations] = useState([]);
  const [messages, setMessages] = useState([]);
  const [activeUser, setActiveUser] = useState(null);
  const [text, setText] = useState('');
  const [loadingConvs, setLoadingConvs] = useState(true);
  const [loadingMsgs, setLoadingMsgs] = useState(false);
  const [sending, setSending] = useState(false);
  const [typing, setTyping] = useState(false);
  const messagesEndRef = useRef(null);
  const typingTimeout = useRef(null);

  const scrollToBottom = () => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });

  // Load conversations
  useEffect(() => {
    api.get('/messages/conversations')
      .then(r => setConversations(r.data))
      .catch(() => {})
      .finally(() => setLoadingConvs(false));
  }, []);

  // Load messages when userId changes
  useEffect(() => {
    if (!userId) return;
    const loadChat = async () => {
      setLoadingMsgs(true);
      try {
        // Try to get user info from conversations or fetch
        const conv = conversations.find(c => c.participants.some(p => p._id === userId));
        if (conv) {
          setActiveUser(conv.participants.find(p => p._id !== user._id));
        } else {
          const { data } = await api.get(`/users/${userId}`);
          setActiveUser(data);
        }
        const { data: msgs } = await api.get(`/messages/${userId}`);
        setMessages(msgs);
      } catch { toast.error('Failed to load messages'); }
      finally { setLoadingMsgs(false); }
    };
    loadChat();
  }, [userId, conversations, user]);

  useEffect(() => { scrollToBottom(); }, [messages]);

  // Socket events
  useEffect(() => {
    const socket = getSocket();
    if (!socket) return;
    const handleNewMessage = (msg) => {
      if (msg.sender._id === userId || msg.receiver === userId) {
        setMessages(prev => [...prev, msg]);
      }
      // Update conversation list
      setConversations(prev => {
        const existing = prev.find(c => c.participants.some(p => p._id === (msg.sender._id || msg.sender)));
        if (existing) {
          return prev.map(c => c._id === existing._id ? { ...c, lastMessage: msg } : c);
        }
        return prev;
      });
    };
    const handleTyping = ({ from }) => { if (from === userId) setTyping(true); };
    const handleStopTyping = ({ from }) => { if (from === userId) setTyping(false); };
    socket.on('new_message', handleNewMessage);
    socket.on('user_typing', handleTyping);
    socket.on('user_stop_typing', handleStopTyping);
    return () => {
      socket.off('new_message', handleNewMessage);
      socket.off('user_typing', handleTyping);
      socket.off('user_stop_typing', handleStopTyping);
    };
  }, [userId]);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!text.trim() || !userId || sending) return;
    setSending(true);
    try {
      const { data } = await api.post(`/messages/${userId}`, { content: text.trim() });
      setMessages(prev => [...prev, data]);
      setText('');
      // Update conversations
      setConversations(prev => {
        const existing = prev.find(c => c.participants.some(p => p._id === userId));
        if (existing) return prev.map(c => c._id === existing._id ? { ...c, lastMessage: data, lastMessageAt: new Date() } : c);
        return prev;
      });
    } catch { toast.error('Failed to send message'); }
    finally { setSending(false); }
  };

  const handleTyping = (e) => {
    setText(e.target.value);
    const socket = getSocket();
    if (!socket || !userId) return;
    socket.emit('typing', { to: userId });
    clearTimeout(typingTimeout.current);
    typingTimeout.current = setTimeout(() => socket.emit('stop_typing', { to: userId }), 1500);
  };

  return (
    <div className="h-[calc(100vh-120px)] flex gap-5">
      {/* Conversations list */}
      <div className={`w-80 flex-shrink-0 card flex flex-col overflow-hidden ${userId ? 'hidden md:flex' : 'flex w-full md:w-80'}`}>
        <div className="p-4 border-b border-slate-100 dark:border-slate-800">
          <h2 className="section-title">Messages</h2>
        </div>
        <div className="flex-1 overflow-y-auto">
          {loadingConvs ? (
            <div className="p-4 space-y-3">
              {[...Array(4)].map((_, i) => <div key={i} className="animate-pulse h-16 bg-slate-100 dark:bg-slate-800 rounded-xl" />)}
            </div>
          ) : conversations.length === 0 ? (
            <div className="p-8 text-center">
              <div className="text-4xl mb-2">💬</div>
              <p className="text-slate-400 text-sm">No conversations yet</p>
              <Link to="/directory" className="text-brand-600 text-sm hover:underline mt-1 block">Find people to message</Link>
            </div>
          ) : (
            conversations.map(conv => {
              const other = conv.participants?.find(p => p._id !== user._id);
              if (!other) return null;
              return (
                <button key={conv._id} onClick={() => navigate(`/messages/${other._id}`)}
                  className={`w-full flex items-center gap-3 p-4 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors text-left border-b border-slate-50 dark:border-slate-800/50 ${
                    userId === other._id ? 'bg-brand-50 dark:bg-brand-950' : ''
                  }`}>
                  {other.avatar
                    ? <img src={other.avatar} className="w-10 h-10 rounded-full object-cover flex-shrink-0" alt="" />
                    : <div className="w-10 h-10 rounded-full bg-brand-100 dark:bg-brand-900 flex items-center justify-center text-brand-700 font-bold flex-shrink-0">
                        {other.name?.[0]}
                      </div>
                  }
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-baseline">
                      <span className="text-sm font-semibold text-slate-800 dark:text-slate-200 truncate">{other.name}</span>
                      {conv.lastMessageAt && (
                        <span className="text-xs text-slate-400 flex-shrink-0 ml-2">
                          {formatDistanceToNow(new Date(conv.lastMessageAt), { addSuffix: false })}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-400 truncate mt-0.5">
                      {conv.lastMessage?.content || 'Start a conversation'}
                    </p>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </div>

      {/* Chat area */}
      {!userId ? (
        <div className="hidden md:flex flex-1 card items-center justify-center">
          <div className="text-center">
            <div className="text-6xl mb-4">💬</div>
            <h3 className="font-semibold text-slate-700 dark:text-slate-300">Select a conversation</h3>
            <p className="text-slate-400 text-sm mt-1">Choose from the list or find someone to message</p>
            <Link to="/directory" className="btn-primary mt-4 inline-flex">Browse Directory</Link>
          </div>
        </div>
      ) : (
        <div className="flex-1 card flex flex-col overflow-hidden min-w-0">
          {/* Chat header */}
          <div className="flex items-center gap-3 p-4 border-b border-slate-100 dark:border-slate-800 flex-shrink-0">
            <button onClick={() => navigate('/messages')} className="md:hidden btn-ghost p-1.5">←</button>
            {activeUser?.avatar
              ? <img src={activeUser.avatar} className="w-9 h-9 rounded-full object-cover" alt="" />
              : <div className="w-9 h-9 rounded-full bg-brand-100 dark:bg-brand-900 flex items-center justify-center text-brand-700 font-bold">
                  {activeUser?.name?.[0] || '?'}
                </div>
            }
            <div>
              <Link to={`/profile/${userId}`} className="font-semibold text-sm text-slate-900 dark:text-slate-100 hover:text-brand-700">
                {activeUser?.name || 'Loading...'}
              </Link>
              {typing && <p className="text-xs text-brand-600 animate-pulse">typing...</p>}
              {!typing && activeUser?.company && <p className="text-xs text-slate-400">{activeUser.company}</p>}
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3">
            {loadingMsgs ? (
              <div className="flex justify-center py-10">
                <div className="w-6 h-6 border-3 border-brand-500 border-t-transparent rounded-full animate-spin" />
              </div>
            ) : messages.length === 0 ? (
              <div className="flex items-center justify-center h-full">
                <div className="text-center text-slate-400">
                  <div className="text-4xl mb-2">👋</div>
                  <p className="text-sm">Say hello to {activeUser?.name?.split(' ')[0]}!</p>
                </div>
              </div>
            ) : (
              messages.map((msg, i) => {
                const isMine = (msg.sender?._id || msg.sender) === user._id;
                const showAvatar = !isMine && (i === 0 || (messages[i - 1]?.sender?._id || messages[i-1]?.sender) !== (msg.sender?._id || msg.sender));
                return (
                  <div key={msg._id || i} className={`flex items-end gap-2 ${isMine ? 'justify-end' : 'justify-start'}`}>
                    {!isMine && (
                      showAvatar
                        ? activeUser?.avatar
                          ? <img src={activeUser.avatar} className="w-7 h-7 rounded-full object-cover flex-shrink-0" alt="" />
                          : <div className="w-7 h-7 rounded-full bg-brand-100 dark:bg-brand-900 flex items-center justify-center text-brand-700 text-xs font-bold flex-shrink-0">
                              {activeUser?.name?.[0]}
                            </div>
                        : <div className="w-7 flex-shrink-0" />
                    )}
                    <div className={`max-w-xs lg:max-w-sm group ${isMine ? 'items-end' : 'items-start'} flex flex-col`}>
                      <div className={`px-4 py-2.5 rounded-2xl text-sm leading-relaxed ${
                        isMine
                          ? 'bg-brand-600 text-white rounded-br-md'
                          : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 rounded-bl-md'
                      }`}>
                        {msg.content}
                      </div>
                      <span className="text-xs text-slate-400 mt-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        {formatTime(msg.createdAt)}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input */}
          <form onSubmit={handleSend} className="flex items-center gap-3 p-4 border-t border-slate-100 dark:border-slate-800 flex-shrink-0">
            <input
              className="input-field flex-1"
              placeholder={`Message ${activeUser?.name?.split(' ')[0] || ''}...`}
              value={text}
              onChange={handleTyping}
              autoFocus
            />
            <button type="submit" disabled={sending || !text.trim()} className="btn-primary p-2.5 aspect-square flex-shrink-0 disabled:opacity-40">
              {sending
                ? <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                : <span className="text-base">→</span>
              }
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
