import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../utils/api';
import toast from 'react-hot-toast';

const CATEGORIES = [
  { value: 'general', label: 'General', emoji: '💬' },
  { value: 'career', label: 'Career', emoji: '💼' },
  { value: 'technical', label: 'Technical', emoji: '⚙️' },
  { value: 'events', label: 'Events', emoji: '📅' },
  { value: 'opportunities', label: 'Opportunities', emoji: '🚀' },
  { value: 'alumni-advice', label: 'Alumni Advice', emoji: '🎓' },
];

export default function CreatePostPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({ title: '', content: '', category: 'general', tags: '' });
  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.title.trim() || !form.content.trim()) return toast.error('Title and content required');
    setLoading(true);
    try {
      const payload = {
        ...form,
        tags: form.tags.split(',').map(t => t.trim()).filter(Boolean),
      };
      const { data } = await api.post('/forum', payload);
      toast.success('Post created!');
      navigate(`/forum/post/${data._id}`);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to create post');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto animate-fade-in">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate(-1)} className="btn-ghost p-2">←</button>
        <h1 className="page-title">New Discussion</h1>
      </div>
      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="card p-6 space-y-4">
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">Title *</label>
            <input className="input-field text-base" placeholder="What's your question or topic?" value={form.title} onChange={set('title')} />
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">Category</label>
            <div className="flex flex-wrap gap-2">
              {CATEGORIES.map(c => (
                <button type="button" key={c.value} onClick={() => setForm(f => ({ ...f, category: c.value }))}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-sm font-medium transition-all border ${
                    form.category === c.value
                      ? 'bg-brand-600 text-white border-brand-600 shadow-sm'
                      : 'bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-slate-700 hover:border-brand-300'
                  }`}>
                  {c.emoji} {c.label}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">Content *</label>
            <textarea
              className="input-field resize-none"
              rows={10}
              placeholder="Share your thoughts, question, or experience in detail..."
              value={form.content}
              onChange={set('content')}
            />
            <p className="text-xs text-slate-400 mt-1 text-right">{form.content.length}/5000</p>
          </div>
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">Tags (comma-separated)</label>
            <input className="input-field" placeholder="interview, google, tips" value={form.tags} onChange={set('tags')} />
          </div>
        </div>
        <div className="flex gap-3">
          <button type="submit" disabled={loading} className="btn-primary flex-1 justify-center">
            {loading ? <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" /> : '✦ Post Discussion'}
          </button>
          <button type="button" onClick={() => navigate(-1)} className="btn-secondary px-6">Cancel</button>
        </div>
      </form>
    </div>
  );
}
