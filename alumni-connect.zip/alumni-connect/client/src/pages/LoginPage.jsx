import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useGoogleLogin } from '@react-oauth/google';
import toast from 'react-hot-toast';
import api from '../utils/api';
import { useAuth } from '../context/AuthContext';

export default function LoginPage() {
  const navigate = useNavigate();
  const { login } = useAuth();
  const [tab, setTab] = useState('email');
  const [role, setRole] = useState('student');
  const [form, setForm] = useState({ email: '', password: '' });
  const [phone, setPhone] = useState('');
  const [otp, setOtp] = useState('');
  const [otpSent, setOtpSent] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleGoogleLogin = useGoogleLogin({
    onSuccess: async (res) => {
      setLoading(true);
      try {
        const { data } = await api.post('/auth/google', { idToken: res.access_token, role });
        login(data.token, data.user);
        toast.success(`Welcome back, ${data.user.name}!`);
        navigate('/dashboard');
      } catch {
        toast.error('Google login failed');
      } finally {
        setLoading(false);
      }
    },
    onError: () => toast.error('Google login failed'),
  });

  const handleEmailLogin = async (e) => {
    e.preventDefault();
    if (!form.email || !form.password) return toast.error('Fill all fields');
    setLoading(true);
    try {
      const { data } = await api.post('/auth/login', form);
      login(data.token, data.user);
      toast.success(`Welcome back, ${data.user.name}!`);
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  const handleSendOtp = async () => {
    if (!phone) return toast.error('Enter phone number');
    setLoading(true);
    try {
      await api.post('/auth/send-otp', { phone });
      setOtpSent(true);
      toast.success('OTP sent! (Check console in dev mode)');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Failed to send OTP');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOtp = async () => {
    if (!otp) return toast.error('Enter OTP');
    setLoading(true);
    try {
      const { data } = await api.post('/auth/verify-otp', { phone, otp, role });
      login(data.token, data.user);
      toast.success('Welcome to Alumni Connect!');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'OTP verification failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex bg-slate-50 dark:bg-slate-950">
      {/* Left panel */}
      <div className="hidden lg:flex flex-1 flex-col justify-between bg-gradient-to-br from-brand-700 via-brand-600 to-brand-800 p-12 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          {[...Array(6)].map((_, i) => (
            <div key={i} className="absolute rounded-full border border-white/40"
              style={{ width: `${200 + i * 100}px`, height: `${200 + i * 100}px`, top: `${-50 + i * 30}px`, left: `${-50 + i * 20}px` }} />
          ))}
        </div>
        <div className="relative">
          <div className="flex items-center gap-3 mb-16">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center font-bold text-xl">A</div>
            <span className="font-bold text-xl">Alumni Connect</span>
          </div>
          <h1 className="text-4xl font-bold leading-tight mb-4">
            Reconnect with your<br />
            <span className="text-brand-200">alma mater community</span>
          </h1>
          <p className="text-brand-200 text-lg">
            Network with alumni, discover opportunities, and stay connected with your college journey.
          </p>
        </div>
        <div className="relative grid grid-cols-3 gap-4">
          {[
            { num: '5,000+', label: 'Alumni' },
            { num: '200+', label: 'Companies' },
            { num: '95%', label: 'Placement Rate' },
          ].map(stat => (
            <div key={stat.label} className="bg-white/10 backdrop-blur rounded-xl p-4">
              <div className="text-2xl font-bold">{stat.num}</div>
              <div className="text-brand-200 text-sm">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Right panel */}
      <div className="flex-1 lg:max-w-md flex flex-col justify-center px-6 sm:px-12 py-12">
        <div className="max-w-sm w-full mx-auto">
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white">Sign in</h2>
            <p className="text-slate-500 dark:text-slate-400 mt-1 text-sm">Welcome back to Alumni Connect</p>
          </div>

          {/* Role selector */}
          <div className="flex gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl mb-6">
            {['student', 'alumni'].map(r => (
              <button
                key={r}
                onClick={() => setRole(r)}
                className={`flex-1 py-2 rounded-lg text-sm font-medium capitalize transition-all ${
                  role === r
                    ? 'bg-white dark:bg-slate-700 text-brand-700 dark:text-brand-300 shadow-sm'
                    : 'text-slate-500 dark:text-slate-400 hover:text-slate-700'
                }`}
              >
                {r === 'student' ? '🎓' : '💼'} {r}
              </button>
            ))}
          </div>

          {/* Tab switcher */}
          <div className="flex gap-1 mb-6 border-b border-slate-200 dark:border-slate-700">
            {['email', 'phone'].map(t => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`pb-3 px-1 text-sm font-medium capitalize transition-all border-b-2 -mb-px ${
                  tab === t
                    ? 'border-brand-600 text-brand-700 dark:text-brand-400'
                    : 'border-transparent text-slate-500 hover:text-slate-700'
                }`}
              >
                {t === 'email' ? '📧' : '📱'} {t}
              </button>
            ))}
          </div>

          {tab === 'email' ? (
            <form onSubmit={handleEmailLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">Email</label>
                <input className="input-field" type="email" placeholder="you@example.com" value={form.email} onChange={e => setForm(f => ({ ...f, email: e.target.value }))} />
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">Password</label>
                <input className="input-field" type="password" placeholder="••••••••" value={form.password} onChange={e => setForm(f => ({ ...f, password: e.target.value }))} />
              </div>
              <button type="submit" disabled={loading} className="btn-primary w-full justify-center">
                {loading ? <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" /> : 'Sign In'}
              </button>
            </form>
          ) : (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">Phone Number</label>
                <input className="input-field" type="tel" placeholder="+91 98765 43210" value={phone} onChange={e => setPhone(e.target.value)} disabled={otpSent} />
              </div>
              {!otpSent ? (
                <button onClick={handleSendOtp} disabled={loading} className="btn-primary w-full justify-center">
                  {loading ? <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" /> : 'Send OTP'}
                </button>
              ) : (
                <>
                  <div>
                    <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">Enter OTP</label>
                    <input className="input-field text-center text-lg tracking-widest" type="text" maxLength={6} placeholder="• • • • • •" value={otp} onChange={e => setOtp(e.target.value)} />
                  </div>
                  <button onClick={handleVerifyOtp} disabled={loading} className="btn-primary w-full justify-center">
                    {loading ? <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" /> : 'Verify & Sign In'}
                  </button>
                  <button onClick={() => setOtpSent(false)} className="w-full text-sm text-slate-500 hover:text-slate-700">← Change number</button>
                </>
              )}
            </div>
          )}

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-200 dark:border-slate-700" /></div>
            <div className="relative flex justify-center"><span className="bg-slate-50 dark:bg-slate-950 px-3 text-xs text-slate-400">or continue with</span></div>
          </div>

          <button
            onClick={() => handleGoogleLogin()}
            disabled={loading}
            className="btn-secondary w-full justify-center gap-3"
          >
            <svg className="w-4 h-4" viewBox="0 0 24 24"><path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
            Continue with Google
          </button>

          <p className="text-center text-sm text-slate-500 dark:text-slate-400 mt-6">
            Don't have an account?{' '}
            <Link to="/register" className="text-brand-600 dark:text-brand-400 font-medium hover:underline">Sign up</Link>
          </p>
          <p className="text-center text-xs text-slate-400 mt-2">
            Demo: admin@alumniconnect.com / password123
          </p>
        </div>
      </div>
    </div>
  );
}
