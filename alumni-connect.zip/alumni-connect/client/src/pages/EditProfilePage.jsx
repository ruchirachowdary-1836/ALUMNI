import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';
import toast from 'react-hot-toast';

const DOMAINS = ['Software Engineering', 'Data Science', 'Product Management', 'Design', 'Finance', 'Marketing', 'Consulting', 'Research', 'Embedded Systems', 'Cloud Computing', 'Entrepreneurship', 'Other'];
const BRANCHES = ['Computer Science', 'Electronics', 'Mechanical', 'Civil', 'Chemical', 'Electrical', 'Information Technology', 'Biotechnology', 'Other'];

export default function EditProfilePage() {
  const { user, updateUser } = useAuth();
  const navigate = useNavigate();
  const [saving, setLoading] = useState(false);
  const [form, setForm] = useState({
    name: user?.name || '',
    bio: user?.bio || '',
    branch: user?.branch || '',
    batch: user?.batch || '',
    company: user?.company || '',
    jobTitle: user?.jobTitle || '',
    location: user?.location || '',
    domain: user?.domain || '',
    skills: user?.skills?.join(', ') || '',
    linkedin: user?.linkedin || '',
    github: user?.github || '',
    website: user?.website || '',
    avatar: user?.avatar || '',
    role: user?.role || 'student',
  });

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const payload = {
        ...form,
        skills: form.skills.split(',').map(s => s.trim()).filter(Boolean),
      };
      const { data } = await api.put('/users/profile', payload);
      updateUser(data);
      toast.success('Profile updated!');
      navigate(`/profile/${user._id}`);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Update failed');
    } finally {
      setLoading(false);
    }
  };

  const Field = ({ label, name, type = 'text', placeholder, as, children }) => (
    <div>
      <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">{label}</label>
      {as === 'textarea'
        ? <textarea className="input-field resize-none" rows={3} placeholder={placeholder} value={form[name]} onChange={set(name)} />
        : as === 'select'
        ? <select className="input-field" value={form[name]} onChange={set(name)}>{children}</select>
        : <input className="input-field" type={type} placeholder={placeholder} value={form[name]} onChange={set(name)} />
      }
    </div>
  );

  return (
    <div className="max-w-2xl mx-auto animate-fade-in">
      <div className="flex items-center gap-3 mb-6">
        <button onClick={() => navigate(-1)} className="btn-ghost p-2">←</button>
        <h1 className="page-title">Edit Profile</h1>
      </div>

      <form onSubmit={handleSubmit} className="space-y-5">
        <div className="card p-6 space-y-4">
          <h2 className="section-title border-b border-slate-100 dark:border-slate-800 pb-3">Basic Info</h2>
          <Field label="Full Name *" name="name" placeholder="Your full name" />
          <Field label="Bio" name="bio" as="textarea" placeholder="Tell us about yourself..." />
          <Field label="Profile Picture URL" name="avatar" placeholder="https://..." />
          <div>
            <label className="block text-xs font-medium text-slate-600 dark:text-slate-400 mb-1.5">I am a</label>
            <div className="flex gap-2 p-1 bg-slate-100 dark:bg-slate-800 rounded-xl">
              {['student', 'alumni'].map(r => (
                <button type="button" key={r} onClick={() => setForm(f => ({ ...f, role: r }))}
                  className={`flex-1 py-2 rounded-lg text-sm font-medium capitalize transition-all ${
                    form.role === r ? 'bg-white dark:bg-slate-700 text-brand-700 shadow-sm' : 'text-slate-500'
                  }`}>
                  {r === 'student' ? '🎓' : '💼'} {r}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="card p-6 space-y-4">
          <h2 className="section-title border-b border-slate-100 dark:border-slate-800 pb-3">Education & Career</h2>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Branch" name="branch" as="select">
              <option value="">Select branch</option>
              {BRANCHES.map(b => <option key={b} value={b}>{b}</option>)}
            </Field>
            <Field label="Batch Year" name="batch" placeholder="e.g. 2022" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Company" name="company" placeholder="Google, Amazon..." />
            <Field label="Job Title" name="jobTitle" placeholder="Software Engineer..." />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Field label="Domain" name="domain" as="select">
              <option value="">Select domain</option>
              {DOMAINS.map(d => <option key={d} value={d}>{d}</option>)}
            </Field>
            <Field label="Location" name="location" placeholder="City, Country" />
          </div>
          <Field label="Skills (comma-separated)" name="skills" placeholder="React, Python, Machine Learning..." />
        </div>

        <div className="card p-6 space-y-4">
          <h2 className="section-title border-b border-slate-100 dark:border-slate-800 pb-3">Social Links</h2>
          <Field label="LinkedIn" name="linkedin" placeholder="https://linkedin.com/in/..." />
          <Field label="GitHub" name="github" placeholder="https://github.com/..." />
          <Field label="Website" name="website" placeholder="https://yoursite.com" />
        </div>

        <div className="flex gap-3">
          <button type="submit" disabled={saving} className="btn-primary flex-1 justify-center">
            {saving ? <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" /> : '✓ Save Changes'}
          </button>
          <button type="button" onClick={() => navigate(-1)} className="btn-secondary px-6">Cancel</button>
        </div>
      </form>
    </div>
  );
}
