import { useState, useEffect } from 'react';
import { Outlet, NavLink, useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useTheme } from '../../context/ThemeContext';
import { connectSocket, disconnectSocket } from '../../utils/socket';

const NAV_ITEMS = [
  { path: '/dashboard', label: 'Dashboard', icon: '⊞' },
  { path: '/directory', label: 'Directory', icon: '◉' },
  { path: '/forum', label: 'Forum', icon: '◈' },
  { path: '/connections', label: 'Connections', icon: '⊛' },
  { path: '/messages', label: 'Messages', icon: '◎' },
  { path: '/announcements', label: 'Announcements', icon: '◆' },
];

export default function Layout() {
  const { user, token, logout } = useAuth();
  const { dark, toggle } = useTheme();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [notifications, setNotifications] = useState(0);

  useEffect(() => {
    if (token) {
      const socket = connectSocket(token);
      socket.on('new_message', () => setNotifications(n => n + 1));
      return () => disconnectSocket();
    }
  }, [token]);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const initials = user?.name?.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2) || 'U';
  const avatarColor = ['bg-brand-500', 'bg-teal-500', 'bg-violet-500', 'bg-amber-500', 'bg-rose-500'];
  const colorIdx = user?.name?.charCodeAt(0) % avatarColor.length || 0;

  return (
    <div className="flex h-screen overflow-hidden bg-slate-50 dark:bg-slate-950">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 z-20 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 z-30 w-64 flex flex-col bg-white dark:bg-slate-900
        border-r border-slate-100 dark:border-slate-800 transition-transform duration-300
        lg:static lg:translate-x-0
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full'}
      `}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-6 py-5 border-b border-slate-100 dark:border-slate-800">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center text-white font-bold text-lg shadow-sm">
            A
          </div>
          <div>
            <div className="font-bold text-slate-900 dark:text-white text-sm leading-none">Alumni</div>
            <div className="text-xs text-brand-600 dark:text-brand-400 font-medium">Connect Portal</div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {NAV_ITEMS.map(item => (
            <NavLink
              key={item.path}
              to={item.path}
              onClick={() => setSidebarOpen(false)}
              className={({ isActive }) =>
                `sidebar-link ${isActive ? 'active' : ''} ${item.path === '/messages' && notifications > 0 ? 'relative notification-dot' : ''}`
              }
            >
              <span className="text-base leading-none w-5 text-center">{item.icon}</span>
              <span>{item.label}</span>
              {item.path === '/messages' && notifications > 0 && (
                <span className="ml-auto bg-rose-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {notifications}
                </span>
              )}
            </NavLink>
          ))}

          {user?.role === 'admin' && (
            <NavLink
              to="/admin"
              onClick={() => setSidebarOpen(false)}
              className={({ isActive }) => `sidebar-link ${isActive ? 'active' : ''}`}
            >
              <span className="text-base leading-none w-5 text-center">⊕</span>
              <span>Admin Panel</span>
            </NavLink>
          )}
        </nav>

        {/* User card */}
        <div className="p-3 border-t border-slate-100 dark:border-slate-800">
          <Link
            to={`/profile/${user?._id}`}
            className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors group"
          >
            {user?.avatar ? (
              <img src={user.avatar} alt={user.name} className="w-9 h-9 rounded-full object-cover" />
            ) : (
              <div className={`w-9 h-9 rounded-full ${avatarColor[colorIdx]} flex items-center justify-center text-white text-sm font-semibold`}>
                {initials}
              </div>
            )}
            <div className="flex-1 min-w-0">
              <div className="text-sm font-semibold text-slate-800 dark:text-slate-200 truncate">{user?.name}</div>
              <div className="text-xs text-slate-500 dark:text-slate-400 capitalize">{user?.role}</div>
            </div>
          </Link>
          <div className="flex items-center gap-1 mt-1">
            <button
              onClick={toggle}
              className="flex-1 flex items-center justify-center gap-2 py-2 text-xs text-slate-500 dark:text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg transition-colors"
            >
              {dark ? '☀️ Light' : '🌙 Dark'}
            </button>
            <button
              onClick={handleLogout}
              className="flex-1 flex items-center justify-center gap-2 py-2 text-xs text-slate-500 dark:text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-lg transition-colors"
            >
              ↩ Logout
            </button>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Topbar (mobile) */}
        <header className="lg:hidden flex items-center justify-between px-4 py-3 bg-white dark:bg-slate-900 border-b border-slate-100 dark:border-slate-800">
          <button
            onClick={() => setSidebarOpen(true)}
            className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <div className="space-y-1.5">
              <span className="block w-5 h-0.5 bg-slate-600 dark:bg-slate-400" />
              <span className="block w-5 h-0.5 bg-slate-600 dark:bg-slate-400" />
              <span className="block w-5 h-0.5 bg-slate-600 dark:bg-slate-400" />
            </div>
          </button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-brand-500 to-brand-700 flex items-center justify-center text-white font-bold text-sm">
              A
            </div>
            <span className="font-bold text-slate-900 dark:text-white text-sm">Alumni Connect</span>
          </div>
          <button onClick={toggle} className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800">
            {dark ? '☀️' : '🌙'}
          </button>
        </header>

        <main className="flex-1 overflow-y-auto">
          <div className="max-w-7xl mx-auto p-4 sm:p-6 animate-fade-in">
            <Outlet />
          </div>
        </main>
      </div>
    </div>
  );
}
