# 🎓 Alumni Connect Portal

A full-stack college networking platform connecting students and alumni with real-time messaging, discussion forums, and career opportunities.

---

## ✨ Features

| Feature | Description |
|---|---|
| 🔐 Authentication | Google OAuth, Phone OTP, Email/Password |
| 👤 Profiles | Rich profiles with skills, education, career |
| 📚 Directory | Searchable/filterable alumni directory |
| 💬 Forum | Q&A discussions with likes, comments, replies |
| 🤝 Connections | Send/accept connection requests |
| 💌 Messaging | Real-time chat with Socket.IO |
| 📢 Announcements | Events, opportunities, news board |
| 🛠 Admin Panel | User management, role control, moderation |
| 🌙 Dark Mode | Full dark/light theme support |

---

## 🧱 Tech Stack

**Frontend:** React 18 + Vite · Tailwind CSS · Axios · Socket.IO Client  
**Backend:** Node.js · Express.js · Socket.IO  
**Database:** MongoDB (Mongoose)  
**Auth:** JWT · Google OAuth · Twilio OTP  
**Deploy:** Render (Web Service + Static Site)  

---

## 🚀 Local Setup

### Prerequisites
- Node.js 18+
- MongoDB Atlas account (or local MongoDB)
- Google Cloud Console project (for OAuth)
- Twilio account (optional, OTP logs to console in dev)

### 1. Clone & Install
```bash
git clone <your-repo-url>
cd alumni-connect
npm run install:all
```

### 2. Configure Environment Variables

**Server:**
```bash
cd server
cp .env.example .env
# Edit .env with your values
```

**Client:**
```bash
cd client
cp .env.example .env
# Edit .env with your values
```

### 3. Seed Database
```bash
npm run seed
```
This creates:
- **Admin:** `admin@alumniconnect.com` / `password123`
- **Alumni:** `priya.sharma@example.com` / `password123`
- **Student:** `ravi.kumar@college.edu` / `password123`
- 8 sample alumni, 2 students, forum posts, announcements

### 4. Run Development Servers
```bash
npm run dev
```
- Frontend: http://localhost:5173  
- Backend API: http://localhost:5000  

---

## ⚙️ Environment Variables

### Server (`server/.env`)

| Variable | Required | Description |
|---|---|---|
| `MONGODB_URI` | ✅ | MongoDB Atlas connection string |
| `JWT_SECRET` | ✅ | Secret for JWT signing (min 32 chars) |
| `CLIENT_URL` | ✅ | Frontend URL for CORS |
| `GOOGLE_CLIENT_ID` | ✅ | Google OAuth client ID |
| `GOOGLE_CLIENT_SECRET` | ✅ | Google OAuth secret |
| `TWILIO_ACCOUNT_SID` | ⚪ | Twilio SID (optional; OTP logs to console if absent) |
| `TWILIO_AUTH_TOKEN` | ⚪ | Twilio auth token |
| `TWILIO_PHONE_NUMBER` | ⚪ | Twilio sender number |

### Client (`client/.env`)

| Variable | Required | Description |
|---|---|---|
| `VITE_API_URL` | ✅ | Backend API URL |
| `VITE_SERVER_URL` | ✅ | Backend server URL (for Socket.IO) |
| `VITE_GOOGLE_CLIENT_ID` | ✅ | Google OAuth client ID |

---

## 📡 API Reference

### Auth
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/auth/google` | Google OAuth login |
| POST | `/api/auth/send-otp` | Send OTP to phone |
| POST | `/api/auth/verify-otp` | Verify OTP & login |
| POST | `/api/auth/register` | Email/password register |
| POST | `/api/auth/login` | Email/password login |

### Users
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/users/me` | Get current user |
| PUT | `/api/users/profile` | Update profile |
| GET | `/api/users/:id` | Get user by ID |

### Directory
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/directory` | Search/filter users |
| GET | `/api/directory/filters` | Get filter options |

### Forum
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/forum` | List posts |
| POST | `/api/forum` | Create post |
| GET | `/api/forum/:id` | Get single post |
| POST | `/api/forum/:id/like` | Like/unlike post |
| POST | `/api/forum/:id/comments` | Add comment |
| POST | `/api/forum/:postId/comments/:commentId/reply` | Reply to comment |
| DELETE | `/api/forum/:id` | Delete post |

### Connections
| Method | Endpoint | Description |
|---|---|---|
| POST | `/api/connections/request/:id` | Send request |
| POST | `/api/connections/respond/:id` | Accept/reject |
| GET | `/api/connections/my` | My connections |
| DELETE | `/api/connections/:id` | Remove connection |

### Messages
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/messages/conversations` | All conversations |
| GET | `/api/messages/:userId` | Chat with user |
| POST | `/api/messages/:userId` | Send message |

### Announcements
| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/announcements` | List announcements |
| POST | `/api/announcements` | Create (alumni/admin) |
| DELETE | `/api/announcements/:id` | Delete |

### Admin
| Method | Endpoint | Auth |
|---|---|---|
| GET | `/api/admin/stats` | Admin only |
| GET | `/api/admin/users` | Admin only |
| PATCH | `/api/admin/users/:id/ban` | Admin only |
| PATCH | `/api/admin/users/:id/role` | Admin only |
| PATCH | `/api/admin/users/:id/approve` | Admin only |

---

## 🌐 Deploying to Render

### Option A — Blueprint (Recommended)

1. Push your code to GitHub
2. Go to [Render Dashboard](https://render.com) → **New Blueprint**
3. Connect your repo — Render auto-detects `render.yaml`
4. Fill in secret environment variables when prompted:
   - `MONGODB_URI`
   - `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET`
   - `VITE_GOOGLE_CLIENT_ID`
   - Twilio vars (optional)
5. Click **Apply** — both services deploy automatically

### Option B — Manual Setup

#### Backend (Web Service)
1. **New Web Service** → connect repo
2. Root Dir: `server`
3. Build: `npm install`
4. Start: `npm start`
5. Add all server env vars from `.env.example`

#### Frontend (Static Site)
1. **New Static Site** → connect repo
2. Root Dir: `client`
3. Build: `npm install && npm run build`
4. Publish: `dist`
5. Add rewrite rule: `/* → /index.html` (200 status)
6. Add `VITE_API_URL` pointing to backend URL
7. Add `VITE_GOOGLE_CLIENT_ID`

### Post-Deploy
- Run seed: SSH into backend → `node seed.js`
- Update Google OAuth **Authorized Origins** with Render URLs
- Update `CLIENT_URL` env var on backend with frontend URL

---

## 📂 Project Structure

```
alumni-connect/
├── client/                   # React frontend (Vite)
│   ├── src/
│   │   ├── components/
│   │   │   └── layout/       # Layout, Sidebar
│   │   ├── context/          # Auth, Theme contexts
│   │   ├── pages/            # All page components
│   │   └── utils/            # API client, Socket.IO
│   ├── .env.example
│   └── vite.config.js
├── server/                   # Express backend
│   ├── models/               # Mongoose models
│   ├── routes/               # API routes
│   ├── middleware/           # Auth middleware
│   ├── utils/                # OTP, Socket.IO setup
│   ├── seed.js               # Sample data seeder
│   ├── index.js              # Entry point
│   └── .env.example
├── render.yaml               # Render deployment config
├── package.json              # Root scripts
└── README.md
```

---

## 🔐 Google OAuth Setup

1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create a project → **APIs & Services** → **Credentials**
3. Create **OAuth 2.0 Client ID** (Web application)
4. Add Authorized JavaScript Origins:
   - `http://localhost:5173` (development)
   - `https://your-frontend.onrender.com` (production)
5. Copy Client ID to both `GOOGLE_CLIENT_ID` (server) and `VITE_GOOGLE_CLIENT_ID` (client)

---

## 📦 ZIP & Deploy

```bash
# Create ZIP for sharing
cd ..
zip -r alumni-connect.zip alumni-connect/ \
  --exclude "*/node_modules/*" \
  --exclude "*/.git/*" \
  --exclude "*/dist/*" \
  --exclude "*/.env"

echo "✅ alumni-connect.zip created"
```

---

## 🧪 Demo Credentials

| Role | Email | Password |
|---|---|---|
| Admin | admin@alumniconnect.com | password123 |
| Alumni | priya.sharma@example.com | password123 |
| Student | ravi.kumar@college.edu | password123 |

---

*Built with ❤️ for college communities*
