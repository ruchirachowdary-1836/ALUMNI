require('dotenv').config();
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./models/User');
const Post = require('./models/Post');
const Announcement = require('./models/Announcement');

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/alumni-connect';

const alumniData = [
  { name: 'Priya Sharma', email: 'priya.sharma@example.com', role: 'alumni', branch: 'Computer Science', batch: '2019', company: 'Google', jobTitle: 'Senior Software Engineer', location: 'Hyderabad', domain: 'Software Engineering', skills: ['React', 'Node.js', 'Python', 'Cloud'], linkedin: 'https://linkedin.com/in/priyasharma', bio: 'Passionate about building scalable systems.' },
  { name: 'Rahul Gupta', email: 'rahul.gupta@example.com', role: 'alumni', branch: 'Electronics', batch: '2018', company: 'Amazon', jobTitle: 'Data Scientist', location: 'Bangalore', domain: 'Data Science', skills: ['ML', 'Python', 'TensorFlow', 'SQL'], linkedin: 'https://linkedin.com/in/rahulgupta', bio: 'ML enthusiast working on recommendation systems.' },
  { name: 'Anjali Reddy', email: 'anjali.reddy@example.com', role: 'alumni', branch: 'Mechanical', batch: '2020', company: 'Tesla', jobTitle: 'Product Manager', location: 'San Francisco', domain: 'Product Management', skills: ['Agile', 'Roadmapping', 'Analytics'], linkedin: 'https://linkedin.com/in/anjalireddy', bio: 'Building next-gen EV products.' },
  { name: 'Karthik Nair', email: 'karthik.nair@example.com', role: 'alumni', branch: 'Computer Science', batch: '2017', company: 'Microsoft', jobTitle: 'Cloud Architect', location: 'Seattle', domain: 'Cloud Computing', skills: ['Azure', 'Kubernetes', 'Docker', 'DevOps'], linkedin: 'https://linkedin.com/in/karthiknair', bio: 'Cloud infrastructure at scale.' },
  { name: 'Sneha Patel', email: 'sneha.patel@example.com', role: 'alumni', branch: 'Civil', batch: '2021', company: 'Infosys', jobTitle: 'Consultant', location: 'Pune', domain: 'Consulting', skills: ['SAP', 'Business Analysis', 'Agile'], linkedin: 'https://linkedin.com/in/snehapatel', bio: 'Digital transformation consultant.' },
  { name: 'Vikram Singh', email: 'vikram.singh@example.com', role: 'alumni', branch: 'Computer Science', batch: '2016', company: 'Startup', jobTitle: 'Founder & CEO', location: 'Delhi', domain: 'Entrepreneurship', skills: ['Leadership', 'Strategy', 'Fundraising'], linkedin: 'https://linkedin.com/in/vikramsingh', bio: 'Serial entrepreneur building EdTech.' },
  { name: 'Meera Krishnan', email: 'meera.k@example.com', role: 'alumni', branch: 'Electronics', batch: '2019', company: 'Qualcomm', jobTitle: 'Embedded Systems Engineer', location: 'Hyderabad', domain: 'Embedded Systems', skills: ['C', 'RTOS', 'ARM', 'Firmware'], linkedin: 'https://linkedin.com/in/meerak', bio: 'Building firmware for next-gen chips.' },
  { name: 'Arjun Mehta', email: 'arjun.mehta@example.com', role: 'alumni', branch: 'Computer Science', batch: '2020', company: 'Flipkart', jobTitle: 'Backend Engineer', location: 'Bangalore', domain: 'Software Engineering', skills: ['Java', 'Spring Boot', 'Kafka', 'Redis'], github: 'https://github.com/arjunmehta', bio: 'Building high-scale e-commerce backend.' },
];

const studentData = [
  { name: 'Ravi Kumar', email: 'ravi.kumar@college.edu', role: 'student', branch: 'Computer Science', batch: '2024', skills: ['JavaScript', 'React', 'Python'], bio: 'Final year CS student interested in full-stack development.' },
  { name: 'Deepa Iyer', email: 'deepa.iyer@college.edu', role: 'student', branch: 'Electronics', batch: '2025', skills: ['IoT', 'Arduino', 'C++'], bio: 'Exploring IoT and embedded systems.' },
];

const adminData = {
  name: 'Admin User', email: 'admin@alumniconnect.com', role: 'admin',
  branch: 'Administration', batch: '2000', bio: 'Platform administrator.',
};

async function seed() {
  try {
    await mongoose.connect(MONGODB_URI);
    console.log('Connected to MongoDB');

    await User.deleteMany({});
    await Post.deleteMany({});
    await Announcement.deleteMany({});

    const password = await bcrypt.hash('password123', 12);

    const adminUser = await User.create({ ...adminData, passwordHash: password, authProvider: 'email', isVerified: true });
    const alumni = await User.insertMany(alumniData.map(a => ({ ...a, passwordHash: password, authProvider: 'email', isVerified: true, isApproved: true })));
    const students = await User.insertMany(studentData.map(s => ({ ...s, passwordHash: password, authProvider: 'email', isVerified: true })));

    // Create connections
    alumni[0].connections = [alumni[1]._id, alumni[2]._id];
    await alumni[0].save();

    // Create posts
    const posts = [
      { title: 'How to crack Google SWE interviews', content: 'After 3 attempts, I finally cracked the Google interview. Here are my key learnings:\n\n1. Focus on Data Structures and Algorithms\n2. Practice system design\n3. Behavioral questions matter a lot\n\nHappy to help anyone preparing!', category: 'career', author: alumni[0]._id, tags: ['google', 'interview', 'swe', 'tips'] },
      { title: 'Best resources for Machine Learning in 2024', content: 'After working at Amazon for 3 years, here are the resources I recommend for anyone starting ML:\n\n- Fast.ai practical courses\n- Andrej Karpathy YouTube series\n- Papers with Code\n- Kaggle competitions\n\nStart with projects, not theory!', category: 'technical', author: alumni[1]._id, tags: ['ml', 'ai', 'learning', 'resources'] },
      { title: 'Networking tips for fresh graduates', content: 'When I graduated, I had zero network. Here is how I built mine from scratch:\n\n1. LinkedIn connections with a personalized note\n2. Alumni events and meetups\n3. Open source contributions\n\nConsistency is key!', category: 'alumni-advice', author: alumni[2]._id, tags: ['networking', 'career', 'freshers'] },
    ];
    await Post.insertMany(posts);

    // Create announcements
    await Announcement.insertMany([
      { title: 'Annual Alumni Meet 2024', content: 'Join us for our Annual Alumni Meet! Connect with classmates, network with industry leaders, and celebrate our college\'s achievements.\n\nDress code: Business Casual\nParking available on campus.', type: 'event', author: adminUser._id, eventDate: new Date('2024-12-15'), location: 'Main Auditorium, Campus', registrationLink: 'https://forms.google.com/example', tags: ['annual-meet', 'networking'], isPinned: true },
      { title: 'Campus Placement Drive - Top Companies', content: 'Exciting placement opportunities! The following companies will be visiting campus next month:\n\n- TCS (120+ openings)\n- Infosys (80+ openings)\n- Wipro (60+ openings)\n\nEligibility: 7.0+ CGPA, no active backlogs.', type: 'opportunity', author: adminUser._id, tags: ['placements', 'jobs', 'campus'], eventDate: new Date('2024-11-20') },
      { title: 'Hackathon 2024 - Register Now!', content: 'The annual inter-college hackathon is back! Theme: AI for Social Good.\n\n- Prize pool: ₹5,00,000\n- Duration: 36 hours\n- Teams of 3-5 members\n- Open to students and recent grads', type: 'event', author: alumni[5]._id, tags: ['hackathon', 'coding', 'competition'], eventDate: new Date('2024-11-10'), registrationLink: 'https://hackathon2024.example.com' },
    ]);

    console.log('✅ Seed data created successfully!');
    console.log('\nAdmin credentials: admin@alumniconnect.com / password123');
    console.log('Alumni credentials: priya.sharma@example.com / password123');
    console.log('Student credentials: ravi.kumar@college.edu / password123');
    process.exit(0);
  } catch (err) {
    console.error('Seed error:', err);
    process.exit(1);
  }
}

seed();
