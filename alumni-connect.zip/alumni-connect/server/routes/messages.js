const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const { Message, Conversation } = require('../models/Message');

const getConversationId = (id1, id2) =>
  [id1.toString(), id2.toString()].sort().join('_');

// Get all conversations
router.get('/conversations', auth, async (req, res) => {
  try {
    const conversations = await Conversation.find({
      participants: req.user._id,
    })
      .populate('participants', 'name avatar company jobTitle')
      .populate('lastMessage')
      .sort({ lastMessageAt: -1 });
    res.json(conversations);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch conversations' });
  }
});

// Get messages between two users
router.get('/:userId', auth, async (req, res) => {
  try {
    const conversationId = getConversationId(req.user._id, req.params.userId);
    const messages = await Message.find({ conversationId })
      .populate('sender', 'name avatar')
      .sort({ createdAt: 1 })
      .limit(100);

    // Mark as read
    await Message.updateMany(
      { conversationId, receiver: req.user._id, isRead: false },
      { isRead: true, readAt: new Date() }
    );
    res.json(messages);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch messages' });
  }
});

// Send message
router.post('/:userId', auth, async (req, res) => {
  try {
    const { content } = req.body;
    if (!content) return res.status(400).json({ message: 'Content required' });

    const conversationId = getConversationId(req.user._id, req.params.userId);
    const message = new Message({
      conversationId,
      sender: req.user._id,
      receiver: req.params.userId,
      content,
    });
    await message.save();

    // Update or create conversation
    await Conversation.findOneAndUpdate(
      { participants: { $all: [req.user._id, req.params.userId] } },
      {
        participants: [req.user._id, req.params.userId],
        lastMessage: message._id,
        lastMessageAt: new Date(),
      },
      { upsert: true, new: true }
    );

    await message.populate('sender', 'name avatar');

    // Emit via socket if available
    const io = req.app.get('io');
    if (io) {
      io.to(req.params.userId).emit('new_message', message);
    }

    res.status(201).json(message);
  } catch (err) {
    res.status(500).json({ message: 'Failed to send message' });
  }
});

module.exports = router;
