const express = require('express');
const router = express.Router();
const { auth, requireAdmin, requireAlumni } = require('../middleware/auth');
const Announcement = require('../models/Announcement');

// Get announcements
router.get('/', auth, async (req, res) => {
  try {
    const { type, page = 1, limit = 10 } = req.query;
    const query = { isActive: true };
    if (type) query.type = type;
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const [items, total] = await Promise.all([
      Announcement.find(query)
        .populate('author', 'name avatar role company')
        .sort({ isPinned: -1, createdAt: -1 })
        .skip(skip)
        .limit(parseInt(limit)),
      Announcement.countDocuments(query),
    ]);
    res.json({ announcements: items, total, pages: Math.ceil(total / parseInt(limit)) });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch announcements' });
  }
});

// Create announcement (alumni or admin)
router.post('/', auth, requireAlumni, async (req, res) => {
  try {
    const { title, content, type, eventDate, location, registrationLink, tags } = req.body;
    if (!title || !content) return res.status(400).json({ message: 'Title and content required' });
    const announcement = new Announcement({
      title, content, type, eventDate, location, registrationLink, tags,
      author: req.user._id,
    });
    await announcement.save();
    await announcement.populate('author', 'name avatar role company');
    res.status(201).json(announcement);
  } catch (err) {
    res.status(500).json({ message: 'Failed to create announcement' });
  }
});

// Delete announcement
router.delete('/:id', auth, async (req, res) => {
  try {
    const item = await Announcement.findById(req.params.id);
    if (!item) return res.status(404).json({ message: 'Not found' });
    if (item.author.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized' });
    }
    await item.deleteOne();
    res.json({ message: 'Deleted successfully' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete' });
  }
});

module.exports = router;
