const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const Post = require('../models/Post');

// Get all posts
router.get('/', auth, async (req, res) => {
  try {
    const { category, search, page = 1, limit = 10, sortBy = 'recent' } = req.query;
    const query = { isSpam: false };
    if (category) query.category = category;
    if (search) {
      query.$or = [
        { title: { $regex: search, $options: 'i' } },
        { content: { $regex: search, $options: 'i' } },
        { tags: { $in: [new RegExp(search, 'i')] } },
      ];
    }
    const sortOptions = {
      recent: { createdAt: -1 },
      popular: { likes: -1 },
      views: { views: -1 },
    };
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const [posts, total] = await Promise.all([
      Post.find(query)
        .populate('author', 'name avatar role company batch')
        .sort({ isPinned: -1, ...(sortOptions[sortBy] || { createdAt: -1 }) })
        .skip(skip)
        .limit(parseInt(limit))
        .select('-comments'),
      Post.countDocuments(query),
    ]);
    res.json({ posts, total, pages: Math.ceil(total / parseInt(limit)), page: parseInt(page) });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch posts' });
  }
});

// Get single post
router.get('/:id', auth, async (req, res) => {
  try {
    const post = await Post.findByIdAndUpdate(
      req.params.id,
      { $inc: { views: 1 } },
      { new: true }
    ).populate('author', 'name avatar role company batch')
     .populate('comments.author', 'name avatar role')
     .populate('comments.replies.author', 'name avatar');
    if (!post) return res.status(404).json({ message: 'Post not found' });
    res.json(post);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch post' });
  }
});

// Create post
router.post('/', auth, async (req, res) => {
  try {
    const { title, content, tags, category } = req.body;
    if (!title || !content) return res.status(400).json({ message: 'Title and content required' });
    const post = new Post({ title, content, tags, category, author: req.user._id });
    await post.save();
    await post.populate('author', 'name avatar role company batch');
    res.status(201).json(post);
  } catch (err) {
    res.status(500).json({ message: 'Failed to create post' });
  }
});

// Like/unlike post
router.post('/:id/like', auth, async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Post not found' });
    const idx = post.likes.indexOf(req.user._id);
    if (idx > -1) post.likes.splice(idx, 1);
    else post.likes.push(req.user._id);
    await post.save();
    res.json({ likes: post.likes.length, liked: idx === -1 });
  } catch (err) {
    res.status(500).json({ message: 'Failed to toggle like' });
  }
});

// Add comment
router.post('/:id/comments', auth, async (req, res) => {
  try {
    const { content } = req.body;
    if (!content) return res.status(400).json({ message: 'Comment content required' });
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Post not found' });
    post.comments.push({ author: req.user._id, content });
    await post.save();
    await post.populate('comments.author', 'name avatar role');
    res.status(201).json(post.comments[post.comments.length - 1]);
  } catch (err) {
    res.status(500).json({ message: 'Failed to add comment' });
  }
});

// Reply to comment
router.post('/:postId/comments/:commentId/reply', auth, async (req, res) => {
  try {
    const { content } = req.body;
    const post = await Post.findById(req.params.postId);
    const comment = post?.comments.id(req.params.commentId);
    if (!comment) return res.status(404).json({ message: 'Comment not found' });
    comment.replies.push({ author: req.user._id, content });
    await post.save();
    res.status(201).json(comment.replies[comment.replies.length - 1]);
  } catch (err) {
    res.status(500).json({ message: 'Failed to add reply' });
  }
});

// Delete post
router.delete('/:id', auth, async (req, res) => {
  try {
    const post = await Post.findById(req.params.id);
    if (!post) return res.status(404).json({ message: 'Post not found' });
    if (post.author.toString() !== req.user._id.toString() && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized' });
    }
    await post.deleteOne();
    res.json({ message: 'Post deleted' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to delete post' });
  }
});

module.exports = router;
