const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const User = require('../models/User');

// Get current user
router.get('/me', auth, async (req, res) => {
  res.json(req.user.toPublicJSON ? req.user.toPublicJSON() : req.user);
});

// Update profile
router.put('/profile', auth, async (req, res) => {
  try {
    const allowed = ['name', 'bio', 'branch', 'batch', 'company', 'jobTitle',
      'location', 'domain', 'skills', 'linkedin', 'github', 'website', 'avatar', 'role'];
    const updates = {};
    allowed.forEach(field => {
      if (req.body[field] !== undefined) updates[field] = req.body[field];
    });

    const user = await User.findByIdAndUpdate(req.user._id, updates, { new: true })
      .select('-passwordHash -otp -otpExpiry');
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: 'Profile update failed' });
  }
});

// Get user by ID
router.get('/:id', auth, async (req, res) => {
  try {
    const user = await User.findById(req.params.id)
      .select('-passwordHash -otp -otpExpiry -phone')
      .populate('connections', 'name avatar company jobTitle batch');
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch user' });
  }
});

module.exports = router;
