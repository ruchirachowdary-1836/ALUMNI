const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const User = require('../models/User');

router.get('/', auth, async (req, res) => {
  try {
    const { search, company, domain, batch, role, sortBy = 'name', page = 1, limit = 12 } = req.query;

    const query = { isBanned: false, isApproved: true };
    if (role) query.role = role;
    else query.role = { $in: ['alumni', 'student'] };

    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { company: { $regex: search, $options: 'i' } },
        { jobTitle: { $regex: search, $options: 'i' } },
      ];
    }
    if (company) query.company = { $regex: company, $options: 'i' };
    if (domain) query.domain = { $regex: domain, $options: 'i' };
    if (batch) query.batch = batch;

    const sortOptions = {
      name: { name: 1 },
      batch: { batch: -1 },
      company: { company: 1 },
      recent: { createdAt: -1 },
    };

    const skip = (parseInt(page) - 1) * parseInt(limit);
    const [users, total] = await Promise.all([
      User.find(query)
        .select('name email avatar branch batch company jobTitle location domain skills linkedin github role isVerified')
        .sort(sortOptions[sortBy] || { name: 1 })
        .skip(skip)
        .limit(parseInt(limit)),
      User.countDocuments(query),
    ]);

    res.json({
      users,
      total,
      pages: Math.ceil(total / parseInt(limit)),
      page: parseInt(page),
    });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch directory' });
  }
});

// Get unique filter options
router.get('/filters', auth, async (req, res) => {
  try {
    const [batches, companies, domains] = await Promise.all([
      User.distinct('batch', { batch: { $ne: '' }, isBanned: false }),
      User.distinct('company', { company: { $ne: '' }, isBanned: false }),
      User.distinct('domain', { domain: { $ne: '' }, isBanned: false }),
    ]);
    res.json({ batches: batches.filter(Boolean).sort(), companies: companies.filter(Boolean).sort(), domains: domains.filter(Boolean).sort() });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch filters' });
  }
});

module.exports = router;
