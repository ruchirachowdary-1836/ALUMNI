const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const User = require('../models/User');

// Send connection request
router.post('/request/:targetId', auth, async (req, res) => {
  try {
    const targetId = req.params.targetId;
    if (targetId === req.user._id.toString()) {
      return res.status(400).json({ message: 'Cannot connect with yourself' });
    }
    const [sender, target] = await Promise.all([
      User.findById(req.user._id),
      User.findById(targetId),
    ]);
    if (!target) return res.status(404).json({ message: 'User not found' });
    if (sender.connections.includes(targetId)) {
      return res.status(400).json({ message: 'Already connected' });
    }
    if (sender.sentRequests.includes(targetId)) {
      return res.status(400).json({ message: 'Request already sent' });
    }
    sender.sentRequests.push(targetId);
    target.pendingRequests.push(req.user._id);
    await Promise.all([sender.save(), target.save()]);
    res.json({ message: 'Connection request sent' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to send request' });
  }
});

// Accept/reject connection
router.post('/respond/:senderId', auth, async (req, res) => {
  try {
    const { action } = req.body;
    const senderId = req.params.senderId;
    const [user, sender] = await Promise.all([
      User.findById(req.user._id),
      User.findById(senderId),
    ]);
    if (!sender) return res.status(404).json({ message: 'User not found' });

    // Remove from pending/sent
    user.pendingRequests = user.pendingRequests.filter(id => id.toString() !== senderId);
    sender.sentRequests = sender.sentRequests.filter(id => id.toString() !== req.user._id.toString());

    if (action === 'accept') {
      user.connections.push(senderId);
      sender.connections.push(req.user._id);
    }
    await Promise.all([user.save(), sender.save()]);
    res.json({ message: action === 'accept' ? 'Connection accepted' : 'Request rejected' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to respond to request' });
  }
});

// Get connections
router.get('/my', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id)
      .populate('connections', 'name avatar company jobTitle batch role')
      .populate('pendingRequests', 'name avatar company jobTitle batch role')
      .populate('sentRequests', 'name avatar company jobTitle batch role');
    res.json({
      connections: user.connections,
      pendingRequests: user.pendingRequests,
      sentRequests: user.sentRequests,
    });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch connections' });
  }
});

// Remove connection
router.delete('/:targetId', auth, async (req, res) => {
  try {
    const targetId = req.params.targetId;
    await Promise.all([
      User.findByIdAndUpdate(req.user._id, { $pull: { connections: targetId } }),
      User.findByIdAndUpdate(targetId, { $pull: { connections: req.user._id } }),
    ]);
    res.json({ message: 'Connection removed' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to remove connection' });
  }
});

module.exports = router;
