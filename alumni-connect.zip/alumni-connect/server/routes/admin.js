const express = require('express');
const router = express.Router();
const { auth, requireAdmin } = require('../middleware/auth');
const User = require('../models/User');
const Post = require('../models/Post');
const Announcement = require('../models/Announcement');

// Stats overview
router.get('/stats', auth, requireAdmin, async (req, res) => {
  try {
    const [totalUsers, students, alumni, totalPosts, totalAnnouncements, bannedUsers] = await Promise.all([
      User.countDocuments({ isBanned: false }),
      User.countDocuments({ role: 'student', isBanned: false }),
      User.countDocuments({ role: 'alumni', isBanned: false }),
      Post.countDocuments({ isSpam: false }),
      Announcement.countDocuments({ isActive: true }),
      User.countDocuments({ isBanned: true }),
    ]);
    res.json({ totalUsers, students, alumni, totalPosts, totalAnnouncements, bannedUsers });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch stats' });
  }
});

// Get all users
router.get('/users', auth, requireAdmin, async (req, res) => {
  try {
    const { search, role, page = 1, limit = 20 } = req.query;
    const query = {};
    if (role) query.role = role;
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
      ];
    }
    const skip = (parseInt(page) - 1) * parseInt(limit);
    const [users, total] = await Promise.all([
      User.find(query).select('-passwordHash -otp').sort({ createdAt: -1 }).skip(skip).limit(parseInt(limit)),
      User.countDocuments(query),
    ]);
    res.json({ users, total, pages: Math.ceil(total / parseInt(limit)) });
  } catch (err) {
    res.status(500).json({ message: 'Failed to fetch users' });
  }
});

// Ban/unban user
router.patch('/users/:id/ban', auth, requireAdmin, async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ message: 'User not found' });
    user.isBanned = !user.isBanned;
    await user.save();
    res.json({ message: `User ${user.isBanned ? 'banned' : 'unbanned'}`, isBanned: user.isBanned });
  } catch (err) {
    res.status(500).json({ message: 'Action failed' });
  }
});

// Change user role
router.patch('/users/:id/role', auth, requireAdmin, async (req, res) => {
  try {
    const { role } = req.body;
    if (!['student', 'alumni', 'admin'].includes(role)) {
      return res.status(400).json({ message: 'Invalid role' });
    }
    const user = await User.findByIdAndUpdate(req.params.id, { role }, { new: true }).select('-passwordHash -otp');
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: 'Failed to update role' });
  }
});

// Approve/verify alumni
router.patch('/users/:id/approve', auth, requireAdmin, async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.params.id,
      { isApproved: true, isVerified: true },
      { new: true }
    ).select('-passwordHash -otp');
    res.json(user);
  } catch (err) {
    res.status(500).json({ message: 'Failed to approve user' });
  }
});

// Mark post as spam
router.patch('/posts/:id/spam', auth, requireAdmin, async (req, res) => {
  try {
    const post = await Post.findByIdAndUpdate(req.params.id, { isSpam: true }, { new: true });
    res.json({ message: 'Post marked as spam' });
  } catch (err) {
    res.status(500).json({ message: 'Failed to mark spam' });
  }
});

// Pin announcement
router.patch('/announcements/:id/pin', auth, requireAdmin, async (req, res) => {
  try {
    const item = await Announcement.findById(req.params.id);
    item.isPinned = !item.isPinned;
    await item.save();
    res.json({ isPinned: item.isPinned });
  } catch (err) {
    res.status(500).json({ message: 'Failed to toggle pin' });
  }
});

module.exports = router;
