const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  email: { type: String, unique: true, sparse: true, lowercase: true },
  phone: { type: String, unique: true, sparse: true },
  passwordHash: { type: String },
  avatar: { type: String, default: '' },
  role: { type: String, enum: ['student', 'alumni', 'admin'], default: 'student' },
  isVerified: { type: Boolean, default: false },
  isApproved: { type: Boolean, default: true },
  isBanned: { type: Boolean, default: false },

  // Profile details
  branch: { type: String, default: '' },
  batch: { type: String, default: '' },
  company: { type: String, default: '' },
  jobTitle: { type: String, default: '' },
  location: { type: String, default: '' },
  bio: { type: String, default: '', maxlength: 500 },
  domain: { type: String, default: '' },
  skills: [{ type: String }],

  // Social links
  linkedin: { type: String, default: '' },
  github: { type: String, default: '' },
  website: { type: String, default: '' },

  // Auth providers
  googleId: { type: String, unique: true, sparse: true },
  authProvider: { type: String, enum: ['google', 'phone', 'email'], default: 'email' },

  // OTP
  otp: { type: String },
  otpExpiry: { type: Date },

  // Connections
  connections: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  pendingRequests: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  sentRequests: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],

  lastSeen: { type: Date, default: Date.now },
  createdAt: { type: Date, default: Date.now },
}, { timestamps: true });

userSchema.pre('save', async function (next) {
  if (this.isModified('passwordHash') && this.passwordHash) {
    this.passwordHash = await bcrypt.hash(this.passwordHash, 12);
  }
  next();
});

userSchema.methods.comparePassword = async function (password) {
  return bcrypt.compare(password, this.passwordHash);
};

userSchema.methods.toPublicJSON = function () {
  const obj = this.toObject();
  delete obj.passwordHash;
  delete obj.otp;
  delete obj.otpExpiry;
  return obj;
};

module.exports = mongoose.model('User', userSchema);
