const mongoose = require('mongoose');

const announcementSchema = new mongoose.Schema({
  author: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  title: { type: String, required: true, maxlength: 200 },
  content: { type: String, required: true, maxlength: 3000 },
  type: {
    type: String,
    enum: ['announcement', 'event', 'opportunity', 'news'],
    default: 'announcement',
  },
  eventDate: { type: Date },
  location: { type: String },
  registrationLink: { type: String },
  isActive: { type: Boolean, default: true },
  isPinned: { type: Boolean, default: false },
  tags: [{ type: String }],
}, { timestamps: true });

module.exports = mongoose.model('Announcement', announcementSchema);
