const twilio = process.env.TWILIO_ACCOUNT_SID ? require('twilio') : null;

const sendOTP = async (phone, otp) => {
  if (process.env.NODE_ENV === 'development' || !process.env.TWILIO_ACCOUNT_SID) {
    console.log(`📱 OTP for ${phone}: ${otp}`);
    return { success: true };
  }
  const client = twilio(process.env.TWILIO_ACCOUNT_SID, process.env.TWILIO_AUTH_TOKEN);
  await client.messages.create({
    body: `Your Alumni Connect OTP is: ${otp}. Valid for 10 minutes.`,
    from: process.env.TWILIO_PHONE_NUMBER,
    to: phone,
  });
  return { success: true };
};

module.exports = { sendOTP };
