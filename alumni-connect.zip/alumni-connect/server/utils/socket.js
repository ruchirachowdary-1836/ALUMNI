const jwt = require('jsonwebtoken');
const User = require('../models/User');

const onlineUsers = new Map();

const setupSocketIO = (io) => {
  io.use(async (socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      if (!token) return next(new Error('Authentication required'));
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback-secret');
      const user = await User.findById(decoded.userId).select('name avatar role');
      if (!user) return next(new Error('User not found'));
      socket.user = user;
      next();
    } catch (err) {
      next(new Error('Invalid token'));
    }
  });

  io.on('connection', (socket) => {
    const userId = socket.user._id.toString();
    onlineUsers.set(userId, socket.id);
    socket.join(userId);

    // Broadcast online status
    io.emit('user_online', { userId, online: true });

    // Handle typing
    socket.on('typing', ({ to }) => {
      socket.to(to).emit('user_typing', { from: userId });
    });

    socket.on('stop_typing', ({ to }) => {
      socket.to(to).emit('user_stop_typing', { from: userId });
    });

    // Handle disconnect
    socket.on('disconnect', () => {
      onlineUsers.delete(userId);
      io.emit('user_online', { userId, online: false });
      User.findByIdAndUpdate(userId, { lastSeen: new Date() }).exec();
    });
  });

  return io;
};

const getOnlineUsers = () => Array.from(onlineUsers.keys());

module.exports = { setupSocketIO, getOnlineUsers };
